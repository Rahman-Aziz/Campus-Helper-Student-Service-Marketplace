<?php
/*
|--------------------------------------------------------------------------
| Payment verification helpers
|--------------------------------------------------------------------------
| Adds the columns used by the "buyer uploads payment proof -> seller
| verifies -> receipt is issued" flow. Safe to call on every request:
| ADD COLUMN IF NOT EXISTS is a no-op once the columns already exist
| (MariaDB / MySQL 8). Mirrors the best-effort ALTER pattern already used
| in profile.php for the qr_code column.
*/

function ensurePaymentColumns($db)
{
    static $done = false;
    if ($done) return;
    $done = true;

    $alters = [
        "ALTER TABLE payments ADD COLUMN IF NOT EXISTS proof_file VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE payments ADD COLUMN IF NOT EXISTS verify_status VARCHAR(20) NOT NULL DEFAULT 'awaiting_proof'",
        "ALTER TABLE payments ADD COLUMN IF NOT EXISTS verified_at DATETIME DEFAULT NULL",
        "ALTER TABLE payments ADD COLUMN IF NOT EXISTS reject_reason VARCHAR(255) DEFAULT NULL",
        // Backfill any pre-existing (already paid) payments so their receipts
        // keep working and they are not dragged into the new pending workflow.
        "UPDATE payments SET verify_status='verified'
            WHERE verify_status='awaiting_proof'
              AND proof_file IS NULL
              AND (paid_at IS NOT NULL OR status IN ('paid','success'))",
    ];

    foreach ($alters as $sql) {
        try { $db->exec($sql); } catch (Exception $e) { /* ignore */ }
    }
}
