<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';


/*
|--------------------------------------------------------------------------
| STAFF AUTH CHECK
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['staff_id'])) {
    header('Location: /pages/staff_login.php');
    exit;
}

$db = getDB();
$staff_id = $_SESSION['staff_id'];

/*
|--------------------------------------------------------------------------
| LOAD TICKETS
|--------------------------------------------------------------------------
*/
$ticketsStmt = $db->query("
    SELECT *
    FROM support_tickets
    ORDER BY 
        status = 'open' DESC,
        created_at DESC
");
$tickets = $ticketsStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| CURRENT TICKET
|--------------------------------------------------------------------------
*/
$ticket_id = (int)($_GET['ticket'] ?? 0);
$currentTicket = null;
$messages = [];

if ($ticket_id > 0) {

    $stmt = $db->prepare("
        SELECT t.*, u.full_name, u.email
        FROM support_tickets t
        LEFT JOIN users u ON u.id = t.user_id
        WHERE t.id = ?
    ");
    $stmt->execute([$ticket_id]);
    $currentTicket = $stmt->fetch();

    if ($currentTicket) {

        $msgStmt = $db->prepare("
            SELECT *
            FROM support_messages
            WHERE ticket_id = ?
            ORDER BY created_at ASC
        ");
        $msgStmt->execute([$ticket_id]);
        $messages = $msgStmt->fetchAll();
    }
}

/*
|--------------------------------------------------------------------------
| SEND MESSAGE
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {

    $ticket_id = (int)$_POST['ticket_id'];
    $message = trim($_POST['message']);

    if ($message !== '') {

        $stmt = $db->prepare("
            INSERT INTO support_messages
            (ticket_id, sender_type, sender_id, message, created_at)
            VALUES (?, 'staff', ?, ?, NOW())
        ");

        $stmt->execute([$ticket_id, $staff_id, $message]);

        // auto-open ticket if closed
        $db->prepare("
            UPDATE support_tickets
            SET status = 'open'
            WHERE id = ?
        ")->execute([$ticket_id]);
    }

    header("Location: /pages/support_team.php?ticket=$ticket_id");
    exit;
}

/*
|--------------------------------------------------------------------------
| CLOSE TICKET
|--------------------------------------------------------------------------
*/
if (isset($_GET['close_ticket'])) {

    $cid = (int)$_GET['close_ticket'];

    $db->prepare("
        UPDATE support_tickets
        SET status = 'closed'
        WHERE id = ?
    ")->execute([$cid]);

    header("Location: /pages/support_team.php?ticket=$cid");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Support Team — CampusHelper</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>
:root{
    --ink:#0e0e14;
    --cream:#f5f3ee;
    --accent:#ff5c35;
    --accent2:#3b82f6;
    --muted:#6b7280;
    --surface:#ffffff;
    --border:#e5e7eb;
}

/* BASE */
body{
    margin:0;
    font-family:'DM Sans',sans-serif;
    background:var(--cream);
    color:var(--ink);
}

/* TOP NAV */
.staff-nav{
    background:var(--ink);
    height:56px;
    display:flex;
    align-items:center;
    gap:16px;
    padding:0 24px;
}

.staff-nav .brand{
    font-family:'Syne',sans-serif;
    font-weight:800;
    color:#fff;
    font-size:1.15rem;
    text-decoration:none;
}

.staff-nav .brand span{ color:var(--accent); }

.staff-nav-right{
    margin-left:auto;
    display:flex;
    gap:6px;
    flex-wrap:wrap;
}

.staff-nav-link{
    color:rgba(255,255,255,.8);
    text-decoration:none;
    font-size:.82rem;
    font-weight:600;
    padding:8px 14px;
    border-radius:8px;
    transition:.2s;
}

.staff-nav-link:hover{ background:rgba(255,255,255,.1); color:#fff; }
.staff-nav-link.active{ background:rgba(255,255,255,.18); color:#fff; }

/* LAYOUT */
.layout{
    display:flex;
    height:calc(100vh - 56px);
}

/* SIDEBAR */
.sidebar{
    width:340px;
    background:var(--surface);
    border-right:1px solid var(--border);
    overflow-y:auto;
}

.sidebar-header{
    padding:18px;
    font-family:'Syne',sans-serif;
    font-weight:700;
    border-bottom:1px solid var(--border);
}

.ticket{
    padding:14px;
    border-bottom:1px solid var(--border);
    transition:.2s;
}

.ticket:hover{
    background:#f9fafb;
}

.ticket a{
    text-decoration:none;
    color:var(--ink);
    font-weight:600;
}

.meta{
    font-size:.75rem;
    color:var(--muted);
    margin-top:6px;
}

.badge{
    display:inline-block;
    padding:4px 10px;
    border-radius:999px;
    font-size:.7rem;
    font-weight:700;
    margin-top:6px;
}

.open{background:#d1fae5;color:#065f46;}
.closed{background:#fee2e2;color:#991b1b;}

/* CHAT */
.chat{
    flex:1;
    display:flex;
    flex-direction:column;
}

.chat-header{
    padding:16px;
    background:var(--surface);
    border-bottom:1px solid var(--border);
    display:flex;
    justify-content:space-between;
    align-items:center;
    font-family:'Syne',sans-serif;
}

.messages{
    flex:1;
    padding:18px;
    overflow-y:auto;
}

.msg{
    max-width:65%;
    padding:10px 12px;
    border-radius:10px;
    margin-bottom:10px;
    font-size:.9rem;
}

.user{
    background:#f3f4f6;
}

.staff{
    background:#dbeafe;
    margin-left:auto;
}

/* FORM */
.form{
    display:flex;
    gap:10px;
    padding:12px;
    border-top:1px solid var(--border);
    background:var(--surface);
}

textarea{
    flex:1;
    resize:none;
    padding:10px;
    border:1px solid var(--border);
    border-radius:8px;
    font-family:inherit;
}

button{
    background:var(--accent2);
    color:#fff;
    border:none;
    padding:10px 16px;
    border-radius:8px;
    cursor:pointer;
    font-weight:600;
}
</style>
</head>

<body>

<nav class="staff-nav">
    <a href="/" class="brand">Campus<span>Helper</span></a>
    <div class="staff-nav-right">
        <a href="/pages/support_team.php" class="staff-nav-link active">🎫 Tickets</a>
        <a href="/pages/staff_services.php" class="staff-nav-link">🛠 Services</a>
        <a href="/pages/staff_reports.php" class="staff-nav-link">🚩 Reports</a>
        <a href="/pages/staff_logout.php" class="staff-nav-link">Logout</a>
    </div>
</nav>

<div class="layout">

    <!-- SIDEBAR -->
    <div class="sidebar">

        <div class="sidebar-header">
            Support Tickets
        </div>

        <?php foreach ($tickets as $t): ?>
            <div class="ticket">

                <a href="?ticket=<?= $t['id'] ?>">
                    #<?= $t['id'] ?> — <?= e($t['subject']) ?>
                </a>

                <div class="meta">
                    <?= date('M j, H:i', strtotime($t['created_at'])) ?>
                </div>

                <div>
                    <span class="badge <?= $t['status'] ?>">
                        <?= strtoupper($t['status']) ?>
                    </span>
                </div>

            </div>
        <?php endforeach; ?>

    </div>

    <!-- CHAT -->
    <div class="chat">

        <?php if (!$currentTicket): ?>

            <div style="padding:20px;">
                Select a ticket to begin.
            </div>

        <?php else: ?>

            <div class="chat-header">

                <div>
                    #<?= $currentTicket['id'] ?> —
                    <?= e($currentTicket['subject']) ?>
                </div>

                <a href="?close_ticket=<?= $currentTicket['id'] ?>"
                   style="color:#ef4444;text-decoration:none;font-weight:600;">
                    Close Ticket
                </a>

            </div>

            <div class="messages" id="msgBox">

                <?php foreach ($messages as $m): ?>
                    <div class="msg <?= $m['sender_type'] ?>">
                        <?= e($m['message']) ?>
                    </div>
                <?php endforeach; ?>

            </div>

            <form class="form" method="POST">

                <input type="hidden" name="ticket_id" value="<?= $currentTicket['id'] ?>">

                <textarea name="message" placeholder="Type reply..." required></textarea>

                <button type="submit" name="send_message">
                    Send
                </button>

            </form>

        <?php endif; ?>

    </div>

</div>

<script>
const box = document.getElementById('msgBox');
if (box) box.scrollTop = box.scrollHeight;
</script>

</body>
</html>