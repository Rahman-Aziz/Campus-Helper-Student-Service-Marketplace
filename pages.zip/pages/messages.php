<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireLogin();

$db = getDB();
$user = currentUser();
$uid = (int)$user['id'];

// One row per conversation partner, ordered by most recent activity.
$stmt = $db->prepare("
    SELECT
        CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END AS partner_id,
        MAX(m.created_at) AS last_time,
        MAX(m.id)         AS last_id
    FROM messages m
    WHERE m.sender_id = ? OR m.receiver_id = ?
    GROUP BY partner_id
    ORDER BY last_time DESC
");
$stmt->execute([$uid, $uid, $uid]);
$rows = $stmt->fetchAll();

$conversations = [];
foreach ($rows as $r) {
    $pid = (int)$r['partner_id'];
    if ($pid === $uid || $pid === 0) continue;

    $pStmt = $db->prepare("SELECT id, username, full_name FROM users WHERE id = ?");
    $pStmt->execute([$pid]);
    $partner = $pStmt->fetch();
    if (!$partner) continue;

    $lastStmt = $db->prepare("SELECT content, sender_id, created_at FROM messages WHERE id = ?");
    $lastStmt->execute([(int)$r['last_id']]);
    $last = $lastStmt->fetch();

    $unreadStmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND sender_id = ? AND is_read = 0");
    $unreadStmt->execute([$uid, $pid]);
    $unread = (int)$unreadStmt->fetchColumn();

    $conversations[] = [
        'partner' => $partner,
        'last'    => $last,
        'unread'  => $unread,
        'time'    => $r['last_time'],
    ];
}

$flash_success = flash('success');
$flash_error = flash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Messages — CampusHelper</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--accent2:#3b82f6;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);}
a{text-decoration:none;color:inherit;}
nav{background:var(--ink);display:flex;align-items:center;gap:16px;padding:0 32px;height:64px;}
.brand{font-family:'Syne',sans-serif;font-weight:800;font-size:1.3rem;color:#fff;}
.brand span{color:var(--accent);}
.btn-ghost{margin-left:auto;color:rgba(255,255,255,.8);background:transparent;border:none;padding:8px 16px;border-radius:8px;font-weight:600;font-size:.85rem;}
.btn-ghost:hover{background:rgba(255,255,255,.1);color:#fff;}
.wrap{max-width:720px;margin:32px auto;padding:0 20px;}
h1{font-family:'Syne',sans-serif;font-size:1.5rem;margin-bottom:18px;}
.flash{padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:.9rem;}
.flash-success{background:#d1fae5;color:#065f46;}
.flash-error{background:#fee2e2;color:#991b1b;}
.card{background:var(--surface);border-radius:14px;box-shadow:0 2px 12px rgba(0,0,0,.06);overflow:hidden;}
.conv{display:flex;align-items:center;gap:14px;padding:16px 18px;border-bottom:1px solid var(--border);transition:background .15s;}
.conv:last-child{border-bottom:none;}
.conv:hover{background:#faf9f6;}
.avatar{width:46px;height:46px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0;}
.conv .meta{flex:1;min-width:0;}
.conv .name{font-weight:700;font-size:.95rem;}
.conv .preview{color:var(--muted);font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;}
.conv .right{text-align:right;flex-shrink:0;display:flex;flex-direction:column;align-items:flex-end;gap:6px;}
.conv .time{font-size:.72rem;color:var(--muted);}
.badge{background:var(--accent);color:#fff;font-size:.7rem;font-weight:700;border-radius:999px;min-width:20px;height:20px;padding:0 6px;display:inline-flex;align-items:center;justify-content:center;}
.empty{text-align:center;padding:50px 20px;color:var(--muted);}
</style>
</head>
<body>
<nav>
    <a href="/" class="brand">Campus<span>Helper</span></a>
    <a href="/pages/dashboard.php" class="btn-ghost">← Dashboard</a>
</nav>

<div class="wrap">
    <?php if ($flash_success): ?><div class="flash flash-success"><?= e($flash_success) ?></div><?php endif; ?>
    <?php if ($flash_error): ?><div class="flash flash-error"><?= e($flash_error) ?></div><?php endif; ?>

    <h1>💬 Messages</h1>

    <div class="card">
        <?php if (empty($conversations)): ?>
            <div class="empty">
                No conversations yet.<br>
                Open a service and tap <strong>Contact Me</strong> to start chatting with a seller.
            </div>
        <?php else: ?>
            <?php foreach ($conversations as $c):
                $p = $c['partner'];
                $ini = strtoupper(substr($p['full_name'] ?: $p['username'], 0, 2));
                $prefix = ($c['last'] && (int)$c['last']['sender_id'] === $uid) ? 'You: ' : '';
            ?>
            <a class="conv" href="/pages/chat.php?with=<?= (int)$p['id'] ?>">
                <div class="avatar"><?= e($ini) ?></div>
                <div class="meta">
                    <div class="name"><?= e($p['full_name']) ?></div>
                    <div class="preview"><?= e($prefix . ($c['last']['content'] ?? '')) ?></div>
                </div>
                <div class="right">
                    <span class="time"><?= $c['time'] ? date('M j', strtotime($c['time'])) : '' ?></span>
                    <?php if ($c['unread'] > 0): ?><span class="badge"><?= $c['unread'] ?></span><?php endif; ?>
                </div>
            </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
