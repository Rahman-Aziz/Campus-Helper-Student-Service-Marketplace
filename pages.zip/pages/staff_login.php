<?php
require_once __DIR__ . '/../includes/db.php';

$db = getDB();
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $db->prepare("SELECT * FROM staff_users WHERE username=?");
    $stmt->execute([$username]);
    $staff = $stmt->fetch();

    if ($staff && password_verify($password, $staff['password_hash'])) {

        $_SESSION['staff_id'] = $staff['id'];

        header("Location: /pages/support_team.php");
        exit;
    }

    $error = "Invalid login";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Staff Login</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>
:root{
    --ink:#0e0e14;
    --cream:#f5f3ee;
    --accent:#ff5c35;
    --accent2:#3b82f6;
    --border:#e5e7eb;
}

body{
    margin:0;
    font-family:'DM Sans',sans-serif;
    background:var(--cream);
    display:flex;
    align-items:center;
    justify-content:center;
    height:100vh;
}

.card{
    background:#fff;
    padding:32px;
    border-radius:16px;
    width:340px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

h2{
    font-family:'Syne',sans-serif;
    margin-bottom:20px;
}

input{
    width:100%;
    padding:10px;
    margin-bottom:12px;
    border:1px solid var(--border);
    border-radius:8px;
}

button{
    width:100%;
    padding:10px;
    background:var(--accent);
    color:#fff;
    border:none;
    border-radius:8px;
    font-weight:600;
    cursor:pointer;
}

button:hover{
    background:#e04a26;
}

.error{
    color:red;
    font-size:.85rem;
    margin-bottom:10px;
}
</style>
</head>

<body>

<div class="card">

<h2>Staff Login</h2>

<?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>

<form method="POST">
    <input name="username" placeholder="Username">
    <input name="password" type="password" placeholder="Password">
    <button type="submit">Login</button>
</form>

</div>

</body>
</html>