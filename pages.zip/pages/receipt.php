<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/payments.php';
requireLogin();

$db = getDB();
$user = currentUser();
ensurePaymentColumns($db);
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    flash('error', 'Invalid receipt ID.');
    header('Location: /pages/dashboard.php?tab=transactions');
    exit;
}

$stmt = $db->prepare("
SELECT p.*, o.id as order_id,
       s.title,
       u.full_name as seller_name,
       o.seller_id
FROM payments p
JOIN orders o ON o.id=p.order_id
JOIN services s ON s.id=o.service_id
JOIN users u ON u.id=o.seller_id
WHERE p.id=? AND (p.payer_id=? OR o.seller_id=?)
");

$stmt->execute([$id, $user['id'], $user['id']]);
$receipt = $stmt->fetch();

if (!$receipt) {
    flash('error', 'Receipt not found.');
    header('Location: /pages/dashboard.php?tab=transactions');
    exit;
}

/*
|--------------------------------------------------------------------------
| RECEIPT IS ONLY ISSUED AFTER THE SELLER VERIFIES THE PAYMENT
|--------------------------------------------------------------------------
*/
$verify = $receipt['verify_status'] ?? 'verified';
if ($verify !== 'verified') {

    $isBuyer = ((int)$receipt['payer_id'] === (int)$user['id']);

    $messages = [
        'awaiting_proof' => $isBuyer
            ? 'You haven\'t uploaded your payment receipt yet. Upload it so the seller can verify your payment.'
            : 'The buyer has not uploaded a payment receipt yet.',
        'submitted' => $isBuyer
            ? 'Your receipt has been submitted and is waiting for the seller to verify it. Your CampusHelper receipt will be issued once verified.'
            : 'A payment receipt is waiting for your verification.',
        'rejected' => $isBuyer
            ? 'Your payment receipt was rejected by the seller. Please upload a corrected receipt.'
            : 'You rejected this payment receipt. Waiting for the buyer to re-upload.',
    ];
    $pendingMsg = $messages[$verify] ?? 'This receipt is not available yet.';
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Receipt Pending — CampusHelper</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
    :root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--accent2:#3b82f6;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);padding:40px 20px;}
    .box{max-width:520px;margin:0 auto;background:var(--surface);border-radius:16px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,.06);text-align:center;}
    .brand{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;margin-bottom:18px;}
    .brand span{color:var(--accent);}
    .icon{font-size:2.6rem;margin-bottom:10px;}
    h1{font-family:'Syne',sans-serif;font-size:1.2rem;margin-bottom:10px;}
    p{color:var(--muted);font-size:.92rem;line-height:1.6;margin-bottom:22px;}
    .btn{display:inline-block;padding:12px 18px;border-radius:10px;background:var(--accent);color:#fff;text-decoration:none;font-weight:700;font-size:.9rem;}
    .btn:hover{background:#e04a26;}
    .btn-alt{background:var(--accent2);}
    .btn-alt:hover{background:#2563eb;}
    </style>
    </head>
    <body>
    <div class="box">
        <div class="brand">Campus<span>Helper</span></div>
        <div class="icon"><?= $verify === 'rejected' ? '⚠️' : '⏳' ?></div>
        <h1>Receipt not issued yet</h1>
        <p><?= e($pendingMsg) ?></p>
        <?php if ($isBuyer && in_array($verify, ['awaiting_proof','rejected'], true)): ?>
            <a class="btn" href="/pages/upload_proof.php?payment_id=<?= (int)$receipt['id'] ?>">Upload Receipt</a>
        <?php elseif (!$isBuyer && $verify === 'submitted'): ?>
            <a class="btn btn-alt" href="/pages/verify_payment.php?payment_id=<?= (int)$receipt['id'] ?>">Review &amp; Verify</a>
        <?php endif; ?>
        <a class="btn btn-alt" href="/pages/dashboard.php?tab=<?= $isBuyer ? 'buying' : 'selling' ?>">← Dashboard</a>
    </div>
    </body>
    </html>
    <?php
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Receipt — CampusHelper</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);padding:40px 20px;color:var(--ink);}
.receipt{max-width:620px;margin:0 auto;background:var(--surface);border-radius:16px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,.06);}
.brand{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;margin-bottom:18px;}
.brand span{color:var(--accent);}
.title{font-size:1.1rem;font-weight:700;margin-bottom:20px;}
.row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);font-size:.92rem;}
.total{font-size:1.15rem;font-weight:700;padding-top:18px;}
.status{display:inline-block;padding:5px 12px;border-radius:20px;background:#d1fae5;color:#065f46;font-size:.8rem;font-weight:600;}
.btn{display:inline-block;margin-top:26px;padding:12px 18px;border-radius:10px;background:var(--accent);color:#fff;text-decoration:none;font-weight:600;}
.btn:hover{background:#e04a26;}
</style>
</head>
<body>
<div class="receipt">
    <div class="brand">Campus<span>Helper</span></div>
    <div class="title">🧾 Payment Receipt</div>

    <div class="row"><span>Transaction Reference</span><span><?= e($receipt['transaction_ref']) ?></span></div>
    <div class="row"><span>Service</span><span><?= e($receipt['title']) ?></span></div>
    <div class="row"><span>Seller</span><span><?= e($receipt['seller_name']) ?></span></div>
    <div class="row"><span>Payment Status</span><span class="status"><?= ucfirst($receipt['status']) ?></span></div>
    <div class="row"><span>Payment Date</span><span><?= date('M j, Y h:i A', strtotime($receipt['paid_at'])) ?></span></div>
    <div class="row total"><span>Total Paid</span><span><?= formatMYR($receipt['amount']) ?></span></div>

    <a href="/pages/dashboard.php?tab=transactions" class="btn">← Back to Transactions</a>
</div>
</body>
</html>
