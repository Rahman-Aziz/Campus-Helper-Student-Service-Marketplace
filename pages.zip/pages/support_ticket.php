<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

requireLogin();

$db = getDB();
$user = currentUser();
$uid = (int)$user['id'];

$ticket_id = (int)($_GET['ticket'] ?? 0);

/*
|--------------------------------------------------------------------------
| LOAD USER TICKETS (LIST VIEW)
|--------------------------------------------------------------------------
*/
$ticketsStmt = $db->prepare("
    SELECT *
    FROM support_tickets
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$ticketsStmt->execute([$uid]);
$tickets = $ticketsStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| LOAD SINGLE TICKET (CHAT VIEW)
|--------------------------------------------------------------------------
*/
$currentTicket = null;
$messages = [];

if ($ticket_id > 0) {

    $stmt = $db->prepare("
        SELECT *
        FROM support_tickets
        WHERE id = ?
        AND user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$ticket_id, $uid]);
    $currentTicket = $stmt->fetch();

    if ($currentTicket) {

        $msgStmt = $db->prepare("
            SELECT *
            FROM support_messages
            WHERE ticket_id = ?
            ORDER BY created_at ASC
        ");
        $msgStmt->execute([$ticket_id]);
        $messages = $msgStmt->fetchAll();
    }
}

/*
|--------------------------------------------------------------------------
| SEND MESSAGE
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'], $_POST['ticket_id'])) {

    $msgTicketId = (int)$_POST['ticket_id'];
    $message = trim($_POST['message']);

    if ($message !== '' && strlen($message) >= 3) {

        $insert = $db->prepare("
            INSERT INTO support_messages
            (ticket_id, sender_type, sender_id, message, created_at)
            VALUES (?, 'user', ?, ?, NOW())
        ");

        $insert->execute([$msgTicketId, $uid, $message]);

        $db->prepare("
            UPDATE support_tickets
            SET status = 'open'
            WHERE id = ?
        ")->execute([$msgTicketId]);
    }

    header("Location: /pages/support_ticket.php?ticket=$msgTicketId");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Support — CampusHelper</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>
:root{
    --ink:#0e0e14;
    --cream:#f5f3ee;
    --accent:#ff5c35;
    --accent2:#3b82f6;
    --surface:#fff;
    --muted:#6b7280;
    --border:#e5e7eb;
}

body{
    margin:0;
    font-family:'DM Sans',sans-serif;
    background:var(--cream);
    color:var(--ink);
}

/* NAV */
nav{
    height:64px;
    background:var(--ink);
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 24px;
}

.brand{
    font-family:'Syne',sans-serif;
    font-weight:800;
    color:#fff;
}

.brand span{ color:var(--accent); }

.nav-links a{
    color:#fff;
    margin-left:14px;
    text-decoration:none;
    font-size:.9rem;
}

/* LAYOUT */
.container{
    max-width:1100px;
    margin:0 auto;
    padding:24px;
    display:grid;
    grid-template-columns: 320px 1fr;
    gap:16px;
}

/* TICKET LIST */
.list{
    background:#fff;
    border-radius:14px;
    padding:12px;
    box-shadow:0 2px 12px rgba(0,0,0,.06);
    height:75vh;
    overflow-y:auto;
}

.ticket{
    padding:12px;
    border-radius:10px;
    margin-bottom:10px;
    background:#f9fafb;
    cursor:pointer;
    text-decoration:none;
    display:block;
}

.ticket:hover{
    background:#eef2ff;
}

.ticket strong{
    display:block;
    font-size:.9rem;
}

.small{
    font-size:.75rem;
    color:var(--muted);
}

/* CHAT */
.chat{
    background:#fff;
    border-radius:14px;
    padding:16px;
    box-shadow:0 2px 12px rgba(0,0,0,.06);
    height:75vh;
    display:flex;
    flex-direction:column;
}

.messages{
    flex:1;
    overflow-y:auto;
    background:#f9fafb;
    padding:10px;
    border-radius:10px;
    display:flex;
    flex-direction:column;
    gap:8px;
}

.msg{
    padding:10px;
    border-radius:10px;
    max-width:70%;
    font-size:.9rem;
}

.user{
    background:#dbeafe;
    align-self:flex-end;
}

.staff{
    background:#dcfce7;
    align-self:flex-start;
}

/* INPUT */
form{
    display:flex;
    gap:10px;
    margin-top:10px;
}

textarea{
    flex:1;
    padding:10px;
    border-radius:10px;
    border:1px solid var(--border);
    resize:none;
}

button{
    background:var(--accent);
    border:none;
    color:#fff;
    padding:10px 14px;
    border-radius:10px;
    cursor:pointer;
    font-weight:600;
}

/* EMPTY STATE */
.empty{
    padding:20px;
    text-align:center;
    color:var(--muted);
}

</style>
</head>

<body>

<nav>
    <div class="brand">Campus<span>Helper</span></div>

    <div class="nav-links">
        <a href="/index.php">Home</a>
        <a href="/pages/dashboard.php">Dashboard</a>
    </div>
</nav>

<div class="container">

    <!-- LEFT: TICKETS -->
    <div class="list">

        <h3 style="margin-bottom:10px;">Active Tickets</h3>

        <?php if (empty($tickets)): ?>
            <div class="empty">No tickets found.</div>
        <?php endif; ?>

        <?php foreach ($tickets as $t): ?>
            <a class="ticket" href="/pages/support_ticket.php?ticket=<?= $t['id'] ?>">
                <strong>#<?= $t['id'] ?> — <?= htmlspecialchars($t['subject']) ?></strong>
                <span class="small"><?= strtoupper($t['status']) ?></span>
            </a>
        <?php endforeach; ?>

    </div>

    <!-- RIGHT: CHAT -->
    <div class="chat">

        <?php if (!$currentTicket): ?>

            <div class="empty">
                Select a ticket to view chat
            </div>

        <?php else: ?>

            <h3>
                Ticket #<?= $currentTicket['id'] ?>
                <span style="font-size:.8rem;color:var(--muted);">
                    (<?= strtoupper($currentTicket['status']) ?>)
                </span>
            </h3>

            <div class="messages">

                <?php foreach ($messages as $m): ?>
                    <div class="msg <?= $m['sender_type'] ?>">
                        <?= htmlspecialchars($m['message']) ?>
                    </div>
                <?php endforeach; ?>

            </div>

            <form method="POST">

                <input type="hidden" name="ticket_id" value="<?= $currentTicket['id'] ?>">

                <textarea name="message" placeholder="Type message..." required></textarea>

                <button type="submit">Send</button>

            </form>

        <?php endif; ?>

    </div>

</div>

</body>
</html>