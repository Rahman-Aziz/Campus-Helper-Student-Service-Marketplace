<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

/*
|--------------------------------------------------------------------------
| STAFF AUTH CHECK
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['staff_id'])) {
    header('Location: /pages/staff_login.php');
    exit;
}

$db = getDB();
$staff_id = $_SESSION['staff_id'];

$allowedStatus = ['active', 'paused', 'deleted'];

/*
|--------------------------------------------------------------------------
| UPDATE / EDIT SERVICE
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_service'])) {

    $id            = (int)$_POST['update_service'];
    $title         = trim($_POST['title'] ?? '');
    $description   = trim($_POST['description'] ?? '');
    $category_id   = (int)($_POST['category_id'] ?? 0);
    $price         = (float)($_POST['price'] ?? 0);
    $delivery_days = max(1, (int)($_POST['delivery_days'] ?? 1));
    $status        = $_POST['status'] ?? 'active';

    if (!in_array($status, $allowedStatus, true)) {
        $status = 'active';
    }

    if ($title === '' || $description === '' || $category_id <= 0 || $price <= 0) {
        flash('error', 'Please fill in all required fields with valid values.');
    } else {
        $db->prepare("
            UPDATE services
            SET title = ?, description = ?, category_id = ?, price = ?, delivery_days = ?, status = ?
            WHERE id = ?
        ")->execute([$title, $description, $category_id, $price, $delivery_days, $status, $id]);

        flash('success', "Service #$id updated successfully.");
    }

    header('Location: /pages/staff_services.php' . (!empty($_POST['filter']) ? '?status=' . urlencode($_POST['filter']) : ''));
    exit;
}

/*
|--------------------------------------------------------------------------
| DELETE / RESTORE / PAUSE SERVICE (status change)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_status'])) {

    $id     = (int)($_POST['service_id'] ?? 0);
    $status = $_POST['set_status'];

    if ($id > 0 && in_array($status, $allowedStatus, true)) {

        $db->prepare("UPDATE services SET status = ? WHERE id = ?")->execute([$status, $id]);

        $messages = [
            'deleted' => "Service #$id has been deleted (removed from the marketplace).",
            'active'  => "Service #$id has been restored and is now active.",
            'paused'  => "Service #$id has been paused.",
        ];

        flash('success', $messages[$status] ?? "Service #$id updated.");
    } else {
        flash('error', 'Invalid request.');
    }

    header('Location: /pages/staff_services.php' . (!empty($_POST['filter']) ? '?status=' . urlencode($_POST['filter']) : ''));
    exit;
}

/*
|--------------------------------------------------------------------------
| LOAD DATA
|--------------------------------------------------------------------------
*/
$categories = $db->query("SELECT * FROM categories ORDER BY id")->fetchAll();

$filter = $_GET['status'] ?? 'all';
if (!in_array($filter, $allowedStatus, true)) {
    $filter = 'all';
}

$sql = "
    SELECT
        s.*,
        u.username,
        u.full_name,
        c.name AS cat_name,
        c.icon AS cat_icon,
        (SELECT COUNT(*) FROM service_reports sr WHERE sr.service_id = s.id AND sr.status = 'pending') AS pending_reports
    FROM services s
    JOIN users u ON u.id = s.seller_id
    JOIN categories c ON c.id = s.category_id
";

$params = [];
if ($filter !== 'all') {
    $sql .= " WHERE s.status = ? ";
    $params[] = $filter;
}

$sql .= " ORDER BY pending_reports DESC, s.id DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$services = $stmt->fetchAll();

// quick counts for filter tabs
$counts = $db->query("SELECT status, COUNT(*) c FROM services GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$totalCount = array_sum($counts);

$flash_success = flash('success');
$flash_error = flash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Service Moderation — CampusHelper Staff</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>
:root{
    --ink:#0e0e14;
    --cream:#f5f3ee;
    --accent:#ff5c35;
    --accent2:#3b82f6;
    --muted:#6b7280;
    --surface:#ffffff;
    --border:#e5e7eb;
}

*{ box-sizing:border-box; margin:0; padding:0; }

body{
    font-family:'DM Sans',sans-serif;
    background:var(--cream);
    color:var(--ink);
}

a{ text-decoration:none; color:inherit; }

nav{
    background:var(--ink);
    height:64px;
    display:flex;
    align-items:center;
    gap:16px;
    padding:0 32px;
}

.brand{
    font-family:'Syne',sans-serif;
    font-weight:800;
    color:#fff;
    font-size:1.3rem;
}

.brand span{ color:var(--accent); }

.nav-right{
    margin-left:auto;
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}

.btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    padding:8px 16px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    font-size:.85rem;
    font-weight:600;
    font-family:'DM Sans',sans-serif;
    transition:.2s;
}

.btn-ghost{ color:#fff; background:transparent; }
.btn-ghost:hover{ background:rgba(255,255,255,.1); }
.btn-ghost.active{ background:rgba(255,255,255,.18); }

.btn-accent{ background:var(--accent); color:#fff; }
.btn-accent:hover{ background:#e04a26; }

.btn-primary{ background:var(--accent2); color:#fff; }
.btn-primary:hover{ background:#2563eb; }

.btn-danger{ background:#ef4444; color:#fff; }
.btn-danger:hover{ background:#dc2626; }

.btn-outline{ background:transparent; color:var(--ink); border:2px solid var(--border); }
.btn-outline:hover{ border-color:var(--accent2); color:var(--accent2); }

.btn-sm{ padding:6px 12px; font-size:.78rem; }

.wrap{
    max-width:1280px;
    margin:0 auto;
    padding:32px 24px;
}

h1{
    font-family:'Syne',sans-serif;
    font-weight:800;
    font-size:1.6rem;
    margin-bottom:6px;
}

.subtitle{ color:var(--muted); font-size:.9rem; margin-bottom:20px; }

.flash{
    margin-bottom:20px;
    padding:14px 18px;
    border-radius:8px;
    font-size:.9rem;
}

.flash-success{ background:#d1fae5; color:#065f46; border-left:4px solid #10b981; }
.flash-error{ background:#fee2e2; color:#991b1b; border-left:4px solid #ef4444; }

.tabs{
    display:flex;
    gap:8px;
    margin-bottom:20px;
    flex-wrap:wrap;
}

.tab{
    background:#fff;
    padding:10px 18px;
    border-radius:8px;
    color:var(--muted);
    font-weight:600;
    font-size:.85rem;
}

.tab.active{ background:var(--ink); color:#fff; }

.card{
    background:#fff;
    border-radius:14px;
    overflow:hidden;
    box-shadow:0 2px 12px rgba(0,0,0,.06);
}

.table-wrap{ overflow-x:auto; }

table{ width:100%; border-collapse:collapse; }

th{
    text-align:left;
    padding:14px;
    border-bottom:2px solid var(--border);
    font-size:.75rem;
    color:var(--muted);
    white-space:nowrap;
    text-transform:uppercase;
    letter-spacing:.03em;
}

td{
    padding:14px;
    border-bottom:1px solid var(--border);
    font-size:.88rem;
    vertical-align:middle;
}

.badge{
    display:inline-block;
    padding:5px 10px;
    border-radius:999px;
    font-size:.72rem;
    font-weight:700;
    white-space:nowrap;
}

.badge-active{ background:#d1fae5; color:#065f46; }
.badge-paused{ background:#fef3c7; color:#92400e; }
.badge-deleted{ background:#fee2e2; color:#991b1b; }

.badge-flag{
    background:#fee2e2;
    color:#991b1b;
}

.badge-flag.zero{
    background:#f3f4f6;
    color:var(--muted);
}

.empty{ text-align:center; padding:48px; color:var(--muted); }

.action-group{
    display:flex;
    gap:6px;
    flex-wrap:wrap;
}

.seller-cell strong{ display:block; font-size:.85rem; }
.seller-cell small{ color:var(--muted); font-size:.75rem; }

/* MODAL */
.modal-overlay{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.6);
    z-index:300;
    align-items:center;
    justify-content:center;
}

.modal-overlay.active{ display:flex; }

.modal{
    background:var(--surface);
    border-radius:16px;
    padding:32px;
    max-width:560px;
    width:92%;
    max-height:90vh;
    overflow-y:auto;
    box-shadow:0 24px 64px rgba(0,0,0,.25);
}

.modal-title{
    font-family:'Syne',sans-serif;
    font-size:1.2rem;
    font-weight:700;
    margin-bottom:16px;
}

.modal-close{
    float:right;
    background:none;
    border:none;
    font-size:1.3rem;
    cursor:pointer;
    color:var(--muted);
}

.form-group{ margin-bottom:14px; }

.form-label{
    display:block;
    font-size:.85rem;
    font-weight:600;
    margin-bottom:6px;
}

.form-input{
    width:100%;
    padding:10px 14px;
    border:2px solid var(--border);
    border-radius:8px;
    font-family:'DM Sans',sans-serif;
    font-size:.9rem;
    outline:none;
}

.form-input:focus{ border-color:var(--accent2); }

textarea.form-input{ resize:vertical; min-height:100px; }

.row2{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }

@media(max-width:600px){
    .row2{ grid-template-columns:1fr; }
}
</style>
</head>

<body>

<nav>
    <a href="/" class="brand">Campus<span>Helper</span></a>

    <div class="nav-right">
        <a href="/pages/support_team.php" class="btn btn-ghost">🎫 Tickets</a>
        <a href="/pages/staff_services.php" class="btn btn-ghost active">🛠 Services</a>
        <a href="/pages/staff_reports.php" class="btn btn-ghost">🚩 Reports</a>
        <a href="/pages/staff_logout.php" class="btn btn-ghost">Logout</a>
    </div>
</nav>

<div class="wrap">

    <h1>Service Moderation</h1>
    <p class="subtitle">Review, edit, pause, restore or delete any listing on the marketplace.</p>

    <?php if ($flash_success): ?>
    <div class="flash flash-success"><?= e($flash_success) ?></div>
    <?php endif; ?>

    <?php if ($flash_error): ?>
    <div class="flash flash-error"><?= e($flash_error) ?></div>
    <?php endif; ?>

    <div class="tabs">
        <a href="?status=all" class="tab <?= $filter === 'all' ? 'active' : '' ?>">All (<?= (int)$totalCount ?>)</a>
        <a href="?status=active" class="tab <?= $filter === 'active' ? 'active' : '' ?>">Active (<?= (int)($counts['active'] ?? 0) ?>)</a>
        <a href="?status=paused" class="tab <?= $filter === 'paused' ? 'active' : '' ?>">Paused (<?= (int)($counts['paused'] ?? 0) ?>)</a>
        <a href="?status=deleted" class="tab <?= $filter === 'deleted' ? 'active' : '' ?>">Deleted (<?= (int)($counts['deleted'] ?? 0) ?>)</a>
    </div>

    <div class="card">
        <div class="table-wrap">

            <?php if (empty($services)): ?>

                <div class="empty">No services found for this filter.</div>

            <?php else: ?>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Service</th>
                        <th>Seller</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Reports</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $s): ?>
                    <tr>
                        <td>#<?= (int)$s['id'] ?></td>
                        <td style="max-width:240px;">
                            <strong><?= e($s['title']) ?></strong>
                        </td>
                        <td class="seller-cell">
                            <strong><?= e($s['full_name']) ?></strong>
                            <small>@<?= e($s['username']) ?></small>
                        </td>
                        <td><?= e($s['cat_icon'] . ' ' . $s['cat_name']) ?></td>
                        <td><?= formatMYR($s['price']) ?></td>
                        <td>
                            <span class="badge badge-<?= e($s['status']) ?>"><?= ucfirst($s['status']) ?></span>
                        </td>
                        <td>
                            <?php if ((int)$s['pending_reports'] > 0): ?>
                                <a href="/pages/staff_reports.php?service_id=<?= (int)$s['id'] ?>" class="badge badge-flag">
                                    🚩 <?= (int)$s['pending_reports'] ?>
                                </a>
                            <?php else: ?>
                                <span class="badge badge-flag zero">0</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-group">
                                <button type="button" class="btn btn-primary btn-sm" onclick='openEdit(<?= json_encode($s, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>
                                    ✏️ Edit
                                </button>

                                <a href="/pages/service.php?id=<?= (int)$s['id'] ?>" target="_blank" class="btn btn-outline btn-sm">
                                    👁 View
                                </a>

                                <?php if ($s['status'] !== 'deleted'): ?>
                                    <form method="POST" onsubmit="return confirm('Delete service #<?= (int)$s['id'] ?>? It will be removed from the marketplace.');">
                                        <input type="hidden" name="service_id" value="<?= (int)$s['id'] ?>">
                                        <input type="hidden" name="set_status" value="deleted">
                                        <input type="hidden" name="filter" value="<?= e($filter) ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">🗑 Delete</button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" onsubmit="return confirm('Restore service #<?= (int)$s['id'] ?> and make it active again?');">
                                        <input type="hidden" name="service_id" value="<?= (int)$s['id'] ?>">
                                        <input type="hidden" name="set_status" value="active">
                                        <input type="hidden" name="filter" value="<?= e($filter) ?>">
                                        <button type="submit" class="btn btn-accent btn-sm">♻ Restore</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php endif; ?>
        </div>
    </div>

</div>

<!-- EDIT SERVICE MODAL -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <button class="modal-close" onclick="closeModal('editModal')">✕</button>
        <div class="modal-title">✏️ Edit Service</div>

        <form method="POST">
            <input type="hidden" name="filter" value="<?= e($filter) ?>">
            <input type="hidden" name="update_service" id="edit_id" value="">

            <div class="form-group">
                <label class="form-label">Title *</label>
                <input type="text" name="title" id="edit_title" class="form-input" required>
            </div>

            <div class="form-group">
                <label class="form-label">Description *</label>
                <textarea name="description" id="edit_description" class="form-input" required></textarea>
            </div>

            <div class="row2">
                <div class="form-group">
                    <label class="form-label">Category *</label>
                    <select name="category_id" id="edit_category" class="form-input" required>
                        <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['id'] ?>"><?= e($c['icon'] . ' ' . $c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Status *</label>
                    <select name="status" id="edit_status" class="form-input" required>
                        <option value="active">Active</option>
                        <option value="paused">Paused</option>
                        <option value="deleted">Deleted</option>
                    </select>
                </div>
            </div>

            <div class="row2">
                <div class="form-group">
                    <label class="form-label">Price (RM) *</label>
                    <input type="number" name="price" id="edit_price" class="form-input" min="0.01" step="0.01" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Delivery Days *</label>
                    <input type="number" name="delivery_days" id="edit_delivery" class="form-input" min="1" max="60" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;padding:12px;">
                Save Changes
            </button>
        </form>
    </div>
</div>

<script>
function openEdit(s) {
    document.getElementById('edit_id').value = s.id;
    document.getElementById('edit_title').value = s.title;
    document.getElementById('edit_description').value = s.description;
    document.getElementById('edit_category').value = s.category_id;
    document.getElementById('edit_status').value = s.status;
    document.getElementById('edit_price').value = s.price;
    document.getElementById('edit_delivery').value = s.delivery_days;
    document.getElementById('editModal').classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === modal) modal.classList.remove('active');
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay').forEach(modal => modal.classList.remove('active'));
    }
});
</script>

</body>
</html>
