<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$db = getDB();
$user = isLoggedIn() ? currentUser() : null;
$user_id = $user['id'] ?? null;

if (!$user_id) {
    flash('error', 'You must be logged in.');
    header("Location: /pages/login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| CREATE TICKET ONLY
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email   = trim($_POST['email'] ?? '');
    $type    = trim($_POST['type'] ?? 'general');
    $message = trim($_POST['message'] ?? '');
    $subject = trim($_POST['subject'] ?? 'Help Request');

    if (!$message) {
        flash('error', 'Message cannot be empty.');
        header("Location: /");
        exit;
    }

    $db->beginTransaction();

    // 1. Create ticket
    $db->prepare("
        INSERT INTO support_tickets
        (user_id, subject, type, status, created_at)
        VALUES (?, ?, ?, 'open', NOW())
    ")->execute([$user_id, $subject, $type]);

    $ticket_id = $db->lastInsertId();

    // 2. First message
    $db->prepare("
        INSERT INTO support_messages
        (ticket_id, sender_type, sender_id, message, created_at)
        VALUES (?, 'user', ?, ?, NOW())
    ")->execute([$ticket_id, $user_id, $message]);

    $db->commit();

    flash('success', 'Ticket created successfully.');
    header("Location: /pages/support_ticket.php?ticket=$ticket_id");
    exit;
}