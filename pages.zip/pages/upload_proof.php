<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/payments.php';
requireLogin();

$db = getDB();
$user = currentUser();
$uid = (int)$user['id'];
ensurePaymentColumns($db);

$payment_id = (int)($_GET['payment_id'] ?? 0);

// Load the payment + related order/service (buyer only)
$stmt = $db->prepare("
    SELECT p.*, o.id AS order_id, o.seller_id, o.service_id, o.status AS order_status,
           s.title, u.full_name AS seller_name
    FROM payments p
    JOIN orders o   ON o.id = p.order_id
    JOIN services s ON s.id = o.service_id
    JOIN users u    ON u.id = o.seller_id
    WHERE p.id = ? AND p.payer_id = ?
");
$stmt->execute([$payment_id, $uid]);
$payment = $stmt->fetch();

if (!$payment) {
    flash('error', 'Payment not found.');
    header('Location: /pages/dashboard.php?tab=buying');
    exit;
}

// Already verified -> straight to the receipt
if ($payment['verify_status'] === 'verified') {
    header('Location: /pages/receipt.php?id=' . $payment_id);
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (empty($_FILES['proof']['name']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please choose your payment receipt file to upload.';
    } else {
        $type = mime_content_type($_FILES['proof']['tmp_name']);
        $allowed = [
            'application/pdf' => 'pdf',
            'image/jpeg'      => 'jpg',
            'image/png'       => 'png',
            'image/webp'      => 'webp',
        ];

        if (!isset($allowed[$type])) {
            $error = 'Receipt must be a PDF, JPG, PNG or WEBP file.';
        } elseif ($_FILES['proof']['size'] > 5 * 1024 * 1024) {
            $error = 'File is too large (max 5 MB).';
        } else {
            $dir = __DIR__ . '/../uploads/receipts';
            if (!is_dir($dir)) mkdir($dir, 0755, true);

            $fname = 'proof_' . $payment_id . '_' . time() . '.' . $allowed[$type];

            if (move_uploaded_file($_FILES['proof']['tmp_name'], $dir . '/' . $fname)) {

                $relPath = '/uploads/receipts/' . $fname;

                $db->prepare("
                    UPDATE payments
                    SET proof_file = ?, verify_status = 'submitted', reject_reason = NULL
                    WHERE id = ? AND payer_id = ?
                ")->execute([$relPath, $payment_id, $uid]);

                // Let the seller know there is something to verify
                $note = 'Payment receipt uploaded for your order "' . $payment['title']
                      . '" (Ref ' . $payment['transaction_ref'] . '). Please verify it from your Sales dashboard.';
                $db->prepare("INSERT INTO messages (sender_id, receiver_id, service_id, content) VALUES (?,?,?,?)")
                   ->execute([$uid, (int)$payment['seller_id'], (int)$payment['service_id'], $note]);

                flash('success', 'Receipt submitted! The seller will verify your payment shortly.');
                header('Location: /pages/dashboard.php?tab=buying');
                exit;
            } else {
                $error = 'Could not save the file. Check folder permissions.';
            }
        }
    }
}

$rejected = ($payment['verify_status'] === 'rejected');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Upload Payment Receipt — CampusHelper</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--accent2:#3b82f6;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:32px 16px;}
.card{background:var(--surface);border-radius:16px;padding:34px;max-width:520px;width:100%;box-shadow:0 8px 40px rgba(0,0,0,.1);}
.brand{font-family:'Syne',sans-serif;font-weight:800;font-size:1.2rem;margin-bottom:20px;display:block;}
.brand span{color:var(--accent);}
h1{font-family:'Syne',sans-serif;font-size:1.35rem;margin-bottom:6px;}
.subtitle{color:var(--muted);font-size:.9rem;margin-bottom:22px;}
.summary{background:#f5f3ee;border-radius:10px;padding:16px;margin-bottom:20px;font-size:.9rem;}
.summary .row{display:flex;justify-content:space-between;padding:6px 0;}
.summary .row b{color:var(--accent);}
.error{background:#fee2e2;color:#991b1b;padding:10px 14px;border-radius:8px;font-size:.85rem;margin-bottom:16px;border-left:4px solid #ef4444;}
.reject{background:#fef3c7;color:#92400e;padding:12px 14px;border-radius:8px;font-size:.85rem;margin-bottom:16px;border-left:4px solid #f59e0b;}
.dropzone{border:2px dashed var(--border);border-radius:12px;padding:22px;text-align:center;margin-bottom:8px;}
.dropzone input{width:100%;margin-top:10px;font-size:.85rem;}
.hint{font-size:.8rem;color:var(--muted);margin:6px 0 20px;line-height:1.5;}
.btn{display:block;width:100%;padding:14px;border-radius:10px;border:none;background:var(--accent);color:#fff;font-family:'DM Sans',sans-serif;font-weight:700;font-size:1rem;cursor:pointer;text-align:center;text-decoration:none;}
.btn:hover{background:#e04a26;}
.btn-back{background:transparent;color:var(--muted);border:2px solid var(--border);margin-top:10px;}
.btn-back:hover{border-color:var(--muted);background:#f5f3ee;}
.steps{font-size:.8rem;color:var(--muted);background:#f9fafb;border-radius:8px;padding:12px 14px;margin-bottom:20px;line-height:1.9;}
.steps b{color:var(--ink);}
</style>
</head>
<body>
<div class="card">
    <span class="brand">Campus<span>Helper</span></span>
    <h1>📤 Upload Payment Receipt</h1>
    <p class="subtitle">Send your bank / e-wallet receipt so the seller can verify your payment.</p>

    <?php if ($rejected): ?>
        <div class="reject">
            ⚠️ Your previous receipt was rejected<?= $payment['reject_reason'] ? ': ' . e($payment['reject_reason']) : '.' ?>
            Please upload a clear, correct receipt.
        </div>
    <?php endif; ?>

    <div class="summary">
        <div class="row"><span>Service</span><span><?= e($payment['title']) ?></span></div>
        <div class="row"><span>Seller</span><span><?= e($payment['seller_name']) ?></span></div>
        <div class="row"><span>Reference</span><span><?= e($payment['transaction_ref']) ?></span></div>
        <div class="row"><span>Amount</span><b><?= formatMYR($payment['amount']) ?></b></div>
    </div>

    <div class="steps">
        <b>What to upload:</b><br>
        The payment confirmation / transfer receipt from your banking or e-wallet app
        (the screen that shows the amount, date and reference). PDF is preferred.
    </div>

    <?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="dropzone">
            📎 Choose your receipt file
            <input type="file" name="proof" accept="application/pdf,image/png,image/jpeg,image/webp" required>
        </div>
        <p class="hint">Accepted: PDF, JPG, PNG, WEBP · max 5 MB.</p>
        <button type="submit" class="btn">Submit Receipt for Verification</button>
        <a href="/pages/dashboard.php?tab=buying" class="btn btn-back">← Do this later</a>
    </form>
</div>
</body>
</html>
