<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/payments.php';

requireLogin();

$db = getDB();
$user = currentUser();
$uid = (int)$user['id'];
ensurePaymentColumns($db);

$tab = $_GET['tab'] ?? 'buying';

/*
|--------------------------------------------------------------------------
| COMPLETE ORDER (SELLER SIDE)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete_order'])) {

    $oid = (int)($_POST['complete_order'] ?? 0);

    if ($oid > 0) {

        $checkStmt = $db->prepare("
            SELECT id, status
            FROM orders
            WHERE id = ?
            AND seller_id = ?
        ");

        $checkStmt->execute([$oid, $uid]);

        $order = $checkStmt->fetch();

        if ($order) {

            if ($order['status'] !== 'completed') {

                $updateStmt = $db->prepare("
                    UPDATE orders
                    SET status = 'completed'
                    WHERE id = ?
                    AND seller_id = ?
                ");

                $updateStmt->execute([$oid, $uid]);

                flash('success', 'Order marked as completed.');

            } else {

                flash('error', 'Order is already completed.');
            }

        } else {

            flash('error', 'Order not found.');
        }
    }

    header('Location: /pages/dashboard.php?tab=selling');
    exit;
}

/*
|--------------------------------------------------------------------------
| SUBMIT REVIEW
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_order_id'])) {

    $oid = (int)($_POST['review_order_id'] ?? 0);

    $rating = max(1, min(5, (int)($_POST['rating'] ?? 5)));

    $comment = trim($_POST['comment'] ?? '');

    $orderStmt = $db->prepare("
        SELECT *
        FROM orders
        WHERE id = ?
        AND buyer_id = ?
        AND status = 'completed'
    ");

    $orderStmt->execute([$oid, $uid]);

    $order = $orderStmt->fetch();

    if (!$order) {

        flash('error', 'You can only review completed orders.');

    } else {

        try {

            $insertReview = $db->prepare("
                INSERT INTO reviews
                (
                    order_id,
                    reviewer_id,
                    seller_id,
                    service_id,
                    rating,
                    comment
                )
                VALUES (?,?,?,?,?,?)
            ");

            $insertReview->execute([
                $oid,
                $uid,
                $order['seller_id'],
                $order['service_id'],
                $rating,
                $comment
            ]);

            flash('success', 'Review submitted successfully.');

        } catch (Exception $e) {

            flash('error', 'You already reviewed this order.');
        }
    }

    header('Location: /pages/dashboard.php?tab=buying');
    exit;
}

/*
|--------------------------------------------------------------------------
| BUYING ORDERS
|--------------------------------------------------------------------------
*/
$buyingStmt = $db->prepare("
    SELECT
        o.*,
        s.title,
        s.price,
        u.full_name AS seller_name,

        r.id AS review_id,

        p.id AS payment_id,
        p.transaction_ref,
        p.status AS payment_status,
        p.verify_status AS verify_status,
        p.amount AS payment_amount,
        p.paid_at

    FROM orders o

    JOIN services s
        ON s.id = o.service_id

    JOIN users u
        ON u.id = o.seller_id

    LEFT JOIN reviews r
        ON r.order_id = o.id

    LEFT JOIN payments p
        ON p.order_id = o.id

    WHERE o.buyer_id = ?

    ORDER BY o.created_at DESC
");

$buyingStmt->execute([$uid]);

$buying = $buyingStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| SELLING ORDERS
|--------------------------------------------------------------------------
*/
$sellingStmt = $db->prepare("
    SELECT
        o.*,
        s.title,
        s.price,
        u.full_name AS buyer_name,

        p.id AS payment_id,
        p.transaction_ref,
        p.status AS payment_status,
        p.verify_status AS verify_status,
        p.proof_file AS proof_file,
        p.amount AS payment_amount,
        p.paid_at

    FROM orders o

    JOIN services s
        ON s.id = o.service_id

    JOIN users u
        ON u.id = o.buyer_id

    LEFT JOIN payments p
        ON p.order_id = o.id

    WHERE o.seller_id = ?

    ORDER BY o.created_at DESC
");

$sellingStmt->execute([$uid]);

$selling = $sellingStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| TRANSACTIONS
|--------------------------------------------------------------------------
*/
$transactionsStmt = $db->prepare("
    SELECT
        p.*,
        o.status AS order_status,
        s.title

    FROM payments p

    JOIN orders o
        ON o.id = p.order_id

    JOIN services s
        ON s.id = o.service_id

    WHERE p.payer_id = ?

    ORDER BY p.paid_at DESC
");

$transactionsStmt->execute([$uid]);

$transactions = $transactionsStmt->fetchAll();

$flash_success = flash('success');
$flash_error = flash('error');

function badgeClass($status)
{
    return match($status) {

        'pending' => 'badge-pending',

        'in_progress' => 'badge-progress',

        'completed' => 'badge-completed',

        'paid' => 'badge-completed',

        'success' => 'badge-completed',

        'verified' => 'badge-completed',

        'failed' => 'badge-cancelled',

        'rejected' => 'badge-cancelled',

        default => 'badge-pending'
    };
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Dashboard — CampusHelper</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>

:root{
    --ink:#0e0e14;
    --cream:#f5f3ee;
    --accent:#ff5c35;
    --accent2:#3b82f6;
    --surface:#fff;
    --muted:#6b7280;
    --border:#e5e7eb;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'DM Sans',sans-serif;
    background:var(--cream);
    color:var(--ink);
}

a{
    text-decoration:none;
    color:inherit;
}

nav{
    background:var(--ink);
    height:64px;
    display:flex;
    align-items:center;
    padding:0 32px;
}

.brand{
    font-family:'Syne',sans-serif;
    font-weight:800;
    color:#fff;
    font-size:1.3rem;
}

.brand span{
    color:var(--accent);
}

.nav-right{
    margin-left:auto;
    display:flex;
    gap:8px;
}

.btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:8px 16px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    font-size:.85rem;
    font-weight:600;
    transition:.2s;
}

.btn-accent{
    background:var(--accent);
    color:#fff;
}

.btn-accent:hover{
    background:#e04a26;
}

.btn-primary{
    background:var(--accent2);
    color:#fff;
}

.btn-primary:hover{
    background:#2563eb;
}

.btn-ghost{
    color:#fff;
    background:transparent;
}

.wrap{
    max-width:1200px;
    margin:0 auto;
    padding:32px 24px;
}

.tabs{
    display:flex;
    gap:8px;
    margin:24px 0;
    flex-wrap:wrap;
}

.tab{
    background:#fff;
    padding:10px 18px;
    border-radius:8px;
    color:var(--muted);
    font-weight:600;
}

.tab.active{
    background:var(--ink);
    color:#fff;
}

.card{
    background:#fff;
    border-radius:14px;
    overflow:hidden;
    box-shadow:0 2px 12px rgba(0,0,0,.06);
}

.table-wrap{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    text-align:left;
    padding:14px;
    border-bottom:2px solid var(--border);
    font-size:.78rem;
    color:var(--muted);
    white-space:nowrap;
}

td{
    padding:14px;
    border-bottom:1px solid var(--border);
    font-size:.88rem;
    vertical-align:middle;
}

.badge{
    display:inline-block;
    padding:5px 10px;
    border-radius:999px;
    font-size:.72rem;
    font-weight:700;
}

.badge-pending{
    background:#fef3c7;
    color:#92400e;
}

.badge-progress{
    background:#dbeafe;
    color:#1e40af;
}

.badge-completed{
    background:#d1fae5;
    color:#065f46;
}

.badge-cancelled{
    background:#fee2e2;
    color:#991b1b;
}

.flash{
    margin:20px;
    padding:14px 18px;
    border-radius:8px;
}

.flash-success{
    background:#d1fae5;
    color:#065f46;
}

.flash-error{
    background:#fee2e2;
    color:#991b1b;
}

.empty{
    text-align:center;
    padding:40px;
    color:var(--muted);
}

.action-group{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}

.review-box{
    margin-top:10px;
    padding:12px;
    background:#f9fafb;
    border-radius:8px;
}

.review-box textarea{
    width:100%;
    margin-top:8px;
    padding:10px;
    border:1px solid var(--border);
    border-radius:8px;
    resize:vertical;
    min-height:80px;
}

.review-box select{
    padding:8px;
    border-radius:8px;
    border:1px solid var(--border);
}

</style>

</head>

<body>

<nav>

    <a href="/" class="brand">
        Campus<span>Helper</span>
    </a>

    <div class="nav-right">

        <a href="/" class="btn btn-ghost">
            Browse
        </a>

        <a href="/pages/create_service.php" class="btn btn-accent">
            + List Service
        </a>

        <a href="/pages/messages.php" class="btn btn-ghost">
            Messages
        </a>

        <a href="/pages/support_ticket.php" class="btn btn-ghost">
            Tickets
        </a>

        <a href="/pages/profile.php" class="btn btn-ghost">
            Profile
        </a>

        <a href="/pages/logout.php" class="btn btn-ghost">
            Logout
        </a>

    </div>

</nav>

<?php if ($flash_success): ?>
<div class="flash flash-success">
    <?= e($flash_success) ?>
</div>
<?php endif; ?>

<?php if ($flash_error): ?>
<div class="flash flash-error">
    <?= e($flash_error) ?>
</div>
<?php endif; ?>

<div class="wrap">

    <h1>
        Welcome back, <?= e($user['full_name']) ?>
    </h1>

    <div class="tabs">

        <a href="?tab=buying" class="tab <?= $tab === 'buying' ? 'active' : '' ?>">
            🛒 Purchases
        </a>

        <a href="?tab=selling" class="tab <?= $tab === 'selling' ? 'active' : '' ?>">
            📦 Sales
        </a>

        <a href="?tab=transactions" class="tab <?= $tab === 'transactions' ? 'active' : '' ?>">
            🧾 Transactions
        </a>

    </div>

    <?php if ($tab === 'buying'): ?>

        <div class="card">
            <div class="table-wrap">

                <?php if (empty($buying)): ?>

                    <div class="empty">
                        No purchases yet.
                    </div>

                <?php else: ?>

                <table>

                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Seller</th>
                            <th>Amount</th>
                            <th>Order Status</th>
                            <th>Receipt</th>
                            <th>Review</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($buying as $o): ?>

                        <tr>

                            <td><?= e($o['title']) ?></td>

                            <td><?= e($o['seller_name']) ?></td>

                            <td><?= formatMYR($o['amount']) ?></td>

                            <td>
                                <span class="badge <?= badgeClass($o['status']) ?>">
                                    <?= ucfirst(str_replace('_', ' ', $o['status'])) ?>
                                </span>
                            </td>

                            <td>

                                <?php
                                    $vs = $o['verify_status'] ?? null;
                                    if (!empty($o['payment_id']) && $vs === 'verified'):
                                ?>

                                    <a
                                        href="/pages/receipt.php?id=<?= $o['payment_id'] ?>"
                                        class="btn btn-primary"
                                    >
                                        View Receipt
                                    </a>

                                <?php elseif (!empty($o['payment_id']) && in_array($vs, ['awaiting_proof','rejected'], true)): ?>

                                    <a
                                        href="/pages/upload_proof.php?payment_id=<?= $o['payment_id'] ?>"
                                        class="btn btn-accent"
                                    >
                                        <?= $vs === 'rejected' ? 'Re-upload Receipt' : 'Upload Receipt' ?>
                                    </a>

                                <?php elseif (!empty($o['payment_id']) && $vs === 'submitted'): ?>

                                    <span class="badge badge-progress">Awaiting verification</span>

                                <?php else: ?>

                                    <span style="color:var(--muted)">
                                        No receipt
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php if (
                                    $o['status'] === 'completed'
                                    && empty($o['review_id'])
                                ): ?>

                                    <form method="POST" class="review-box">

                                        <input
                                            type="hidden"
                                            name="review_order_id"
                                            value="<?= $o['id'] ?>"
                                        >

                                        <select name="rating" required>
                                            <option value="5">★★★★★</option>
                                            <option value="4">★★★★☆</option>
                                            <option value="3">★★★☆☆</option>
                                            <option value="2">★★☆☆☆</option>
                                            <option value="1">★☆☆☆☆</option>
                                        </select>

                                        <textarea
                                            name="comment"
                                            placeholder="Leave your review..."
                                            required
                                        ></textarea>

                                        <button
                                            type="submit"
                                            class="btn btn-accent"
                                        >
                                            Submit Review
                                        </button>

                                    </form>

                                <?php elseif (!empty($o['review_id'])): ?>

                                    <span style="color:green;font-weight:600;">
                                        Review Submitted
                                    </span>

                                <?php else: ?>

                                    <span style="color:var(--muted);">
                                        Complete order first
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

                <?php endif; ?>

            </div>
        </div>

    <?php elseif ($tab === 'selling'): ?>

        <div class="card">
            <div class="table-wrap">

                <?php if (empty($selling)): ?>

                    <div class="empty">
                        No sales yet.
                    </div>

                <?php else: ?>

                <table>

                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Buyer</th>
                            <th>Earnings</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Receipt</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($selling as $o): ?>

                        <tr>

                            <td><?= e($o['title']) ?></td>

                            <td><?= e($o['buyer_name']) ?></td>

                            <td><?= formatMYR($o['seller_earnings']) ?></td>

                            <td>
                                <span class="badge <?= badgeClass($o['status']) ?>">
                                    <?= ucfirst(str_replace('_', ' ', $o['status'])) ?>
                                </span>
                            </td>

                            <td>

                                <?php $vs = $o['verify_status'] ?? null; ?>

                                <?php if (empty($o['payment_id'])): ?>

                                    <span style="color:var(--muted)">—</span>

                                <?php elseif ($vs === 'submitted'): ?>

                                    <a
                                        href="/pages/verify_payment.php?payment_id=<?= $o['payment_id'] ?>"
                                        class="btn btn-accent"
                                    >
                                        Verify Payment
                                    </a>

                                <?php elseif ($vs === 'verified'): ?>

                                    <span class="badge badge-completed">Verified</span>

                                <?php elseif ($vs === 'rejected'): ?>

                                    <span class="badge badge-cancelled">Rejected</span>

                                <?php else: ?>

                                    <span class="badge badge-pending">Awaiting receipt</span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php if (!empty($o['payment_id']) && ($o['verify_status'] ?? null) === 'verified'): ?>

                                    <a
                                        href="/pages/receipt.php?id=<?= $o['payment_id'] ?>"
                                        class="btn btn-primary"
                                    >
                                        Receipt
                                    </a>

                                <?php else: ?>

                                    <span style="color:var(--muted)">
                                        No receipt
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <?php if ($o['status'] !== 'completed'): ?>

                                    <form method="POST">

                                        <input
                                            type="hidden"
                                            name="complete_order"
                                            value="<?= $o['id'] ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-accent"
                                            onclick="return confirm('Mark order as completed?')"
                                        >
                                            Mark Complete
                                        </button>

                                    </form>

                                <?php else: ?>

                                    <span style="color:green;font-weight:600;">
                                        Completed
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

                <?php endif; ?>

            </div>
        </div>

    <?php elseif ($tab === 'transactions'): ?>

        <div class="card">
            <div class="table-wrap">

                <?php if (empty($transactions)): ?>

                    <div class="empty">
                        No transactions yet.
                    </div>

                <?php else: ?>

                <table>

                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Payment</th>
                            <th>Order</th>
                            <th>Date</th>
                            <th>Receipt</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($transactions as $trx): ?>

                        <tr>

                            <td><?= e($trx['transaction_ref']) ?></td>

                            <td><?= e($trx['title']) ?></td>

                            <td><?= formatMYR($trx['amount']) ?></td>

                            <td>
                                <span class="badge <?= badgeClass($trx['status']) ?>">
                                    <?= ucfirst($trx['status']) ?>
                                </span>
                            </td>

                            <td>
                                <span class="badge <?= badgeClass($trx['order_status']) ?>">
                                    <?= ucfirst(str_replace('_', ' ', $trx['order_status'])) ?>
                                </span>
                            </td>

                            <td>
                                <?= date('M j, Y h:i A', strtotime($trx['paid_at'])) ?>
                            </td>

                            <td>

                                <a
                                    href="/pages/receipt.php?id=<?= $trx['id'] ?>"
                                    class="btn btn-primary"
                                >
                                    View Receipt
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

                <?php endif; ?>

            </div>
        </div>

    <?php endif; ?>

</div>

</body>
</html>