<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /');
    exit;
}

$service_id = (int)($_POST['service_id'] ?? 0);
$reason     = trim($_POST['reason'] ?? '');
$details    = trim($_POST['details'] ?? '');
$redirect   = $_POST['redirect'] ?? ('/pages/service.php?id=' . $service_id);

// keep redirects local to this app
if (strpos($redirect, '//') === 0 || strpos($redirect, 'http') === 0) {
    $redirect = '/pages/service.php?id=' . $service_id;
}

$validReasons = [
    'scam'         => 'Scam or fraud',
    'inappropriate'=> 'Inappropriate content',
    'misleading'   => 'Misleading description',
    'spam'         => 'Spam or duplicate listing',
    'other'        => 'Other',
];

if ($service_id <= 0 || $reason === '' || !isset($validReasons[$reason])) {
    flash('error', 'Please choose a valid reason for your report.');
    header('Location: ' . $redirect);
    exit;
}

$check = $db->prepare("SELECT id FROM services WHERE id = ?");
$check->execute([$service_id]);

if (!$check->fetch()) {
    flash('error', 'Service not found.');
    header('Location: /');
    exit;
}

$reporter_id = isLoggedIn() ? currentUser()['id'] : null;

$stmt = $db->prepare("
    INSERT INTO service_reports (service_id, reporter_id, reason, details)
    VALUES (?, ?, ?, ?)
");
$stmt->execute([$service_id, $reporter_id, $validReasons[$reason], $details]);

flash('success', 'Thanks for letting us know. Our team will review this listing shortly.');
header('Location: ' . $redirect);
exit;
