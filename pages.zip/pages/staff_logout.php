<?php
require_once __DIR__ . '/../includes/auth.php';

unset($_SESSION['staff_id']);

header('Location: /pages/staff_login.php');
exit;
