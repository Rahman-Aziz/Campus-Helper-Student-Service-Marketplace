<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireLogin();

$db = getDB();
$user = currentUser();
$uid = (int)$user['id'];

$partner_id = (int)($_GET['with'] ?? 0);
$service_id = (int)($_GET['service_id'] ?? 0) ?: null;

if ($partner_id <= 0 || $partner_id === $uid) {
    flash('error', 'Invalid conversation.');
    header('Location: /pages/messages.php');
    exit;
}

// Make sure the partner exists
$pStmt = $db->prepare("SELECT id, username, full_name, university FROM users WHERE id = ?");
$pStmt->execute([$partner_id]);
$partner = $pStmt->fetch();

if (!$partner) {
    flash('error', 'User not found.');
    header('Location: /pages/messages.php');
    exit;
}

// Mark messages from this partner as read
$db->prepare("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?")
   ->execute([$uid, $partner_id]);

// Load the full thread between the two users
$thread = $db->prepare("
    SELECT m.*
    FROM messages m
    WHERE (m.sender_id = ? AND m.receiver_id = ?)
       OR (m.sender_id = ? AND m.receiver_id = ?)
    ORDER BY m.created_at ASC, m.id ASC
");
$thread->execute([$uid, $partner_id, $partner_id, $uid]);
$messages = $thread->fetchAll();

// Optional service context (so "Contact Me" keeps the listing attached)
$service = null;
if ($service_id) {
    $sStmt = $db->prepare("SELECT id, title FROM services WHERE id = ?");
    $sStmt->execute([$service_id]);
    $service = $sStmt->fetch();
}

$self_redirect = '/pages/chat.php?with=' . $partner_id . ($service_id ? '&service_id=' . $service_id : '');
$flash_error = flash('error');
$initials = strtoupper(substr($partner['full_name'] ?: $partner['username'], 0, 2));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Chat with <?= e($partner['full_name']) ?> — CampusHelper</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--accent2:#3b82f6;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);}
a{text-decoration:none;color:inherit;}
nav{background:var(--ink);display:flex;align-items:center;gap:16px;padding:0 32px;height:64px;}
.brand{font-family:'Syne',sans-serif;font-weight:800;font-size:1.3rem;color:#fff;}
.brand span{color:var(--accent);}
.btn-ghost{margin-left:auto;color:rgba(255,255,255,.8);background:transparent;border:none;padding:8px 16px;border-radius:8px;font-weight:600;font-size:.85rem;}
.btn-ghost:hover{background:rgba(255,255,255,.1);color:#fff;}
.wrap{max-width:760px;margin:28px auto;padding:0 20px;}
.chat-card{background:var(--surface);border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,.06);overflow:hidden;display:flex;flex-direction:column;height:calc(100vh - 150px);min-height:480px;}
.chat-head{display:flex;align-items:center;gap:12px;padding:16px 20px;border-bottom:1px solid var(--border);background:#fff;}
.avatar{width:42px;height:42px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.95rem;flex-shrink:0;}
.chat-head .who{font-weight:700;font-size:1rem;}
.chat-head .sub{font-size:.8rem;color:var(--muted);}
.chat-context{font-size:.78rem;color:var(--muted);padding:8px 20px;background:#f9fafb;border-bottom:1px solid var(--border);}
.chat-context a{color:var(--accent2);font-weight:600;}
.messages{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:10px;background:#faf9f6;}
.bubble{max-width:72%;padding:10px 14px;border-radius:16px;font-size:.9rem;line-height:1.45;word-wrap:break-word;position:relative;}
.bubble .time{display:block;font-size:.68rem;opacity:.6;margin-top:4px;}
.mine{align-self:flex-end;background:var(--accent);color:#fff;border-bottom-right-radius:4px;}
.theirs{align-self:flex-start;background:#fff;color:var(--ink);border:1px solid var(--border);border-bottom-left-radius:4px;}
.empty-thread{text-align:center;color:var(--muted);font-size:.9rem;margin:auto;padding:30px;}
.composer{display:flex;gap:10px;padding:14px 16px;border-top:1px solid var(--border);background:#fff;}
.composer textarea{flex:1;resize:none;border:2px solid var(--border);border-radius:10px;padding:10px 14px;font-family:'DM Sans',sans-serif;font-size:.9rem;outline:none;max-height:120px;}
.composer textarea:focus{border-color:var(--accent2);}
.composer button{background:var(--accent);color:#fff;border:none;border-radius:10px;padding:0 22px;font-weight:700;font-size:.9rem;cursor:pointer;transition:background .2s;}
.composer button:hover{background:#e04a26;}
.flash-error{margin:14px 20px 0;padding:10px 14px;border-radius:8px;background:#fee2e2;color:#991b1b;font-size:.85rem;}
</style>
</head>
<body>
<nav>
    <a href="/" class="brand">Campus<span>Helper</span></a>
    <a href="/pages/messages.php" class="btn-ghost">← All Messages</a>
</nav>

<div class="wrap">
    <?php if ($flash_error): ?><div class="flash-error"><?= e($flash_error) ?></div><?php endif; ?>
    <div class="chat-card">
        <div class="chat-head">
            <div class="avatar"><?= e($initials) ?></div>
            <div>
                <div class="who"><?= e($partner['full_name']) ?></div>
                <div class="sub">@<?= e($partner['username']) ?><?= $partner['university'] ? ' · ' . e($partner['university']) : '' ?></div>
            </div>
        </div>

        <?php if ($service): ?>
        <div class="chat-context">
            About listing: <a href="/pages/service.php?id=<?= (int)$service['id'] ?>"><?= e($service['title']) ?></a>
        </div>
        <?php endif; ?>

        <div class="messages" id="messages">
            <?php if (empty($messages)): ?>
                <div class="empty-thread">No messages yet. Say hello 👋</div>
            <?php else: ?>
                <?php foreach ($messages as $m): ?>
                    <div class="bubble <?= ((int)$m['sender_id'] === $uid) ? 'mine' : 'theirs' ?>">
                        <?= nl2br(e($m['content'])) ?>
                        <span class="time"><?= date('M j, g:i A', strtotime($m['created_at'])) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <form class="composer" method="POST" action="/pages/send_message.php">
            <input type="hidden" name="receiver_id" value="<?= $partner_id ?>">
            <?php if ($service_id): ?><input type="hidden" name="service_id" value="<?= $service_id ?>"><?php endif; ?>
            <input type="hidden" name="redirect" value="<?= e($self_redirect) ?>">
            <textarea name="content" id="content" placeholder="Type a message..." required minlength="1" rows="1"></textarea>
            <button type="submit">Send</button>
        </form>
    </div>
</div>

<script>
// keep the newest messages in view
var box = document.getElementById('messages');
if (box) box.scrollTop = box.scrollHeight;
// auto-grow the textarea; Enter sends, Shift+Enter = newline
var ta = document.getElementById('content');
ta.addEventListener('input', function(){
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});
ta.addEventListener('keydown', function(e){
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (this.value.trim() !== '') this.form.submit();
    }
});
</script>
</body>
</html>
