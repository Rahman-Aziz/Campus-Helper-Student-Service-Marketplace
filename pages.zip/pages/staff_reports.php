<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

/*
|--------------------------------------------------------------------------
| STAFF AUTH CHECK
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['staff_id'])) {
    header('Location: /pages/staff_login.php');
    exit;
}

$db = getDB();
$staff_id = $_SESSION['staff_id'];

/*
|--------------------------------------------------------------------------
| APPROVE REPORT (dismiss — service stays as-is)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_report'])) {

    $report_id = (int)$_POST['approve_report'];

    $db->prepare("
        UPDATE service_reports
        SET status = 'approved', resolved_by = ?, resolved_at = NOW()
        WHERE id = ? AND status = 'pending'
    ")->execute([$staff_id, $report_id]);

    flash('success', "Report #$report_id approved — no action taken on the service.");

    header('Location: /pages/staff_reports.php' . (!empty($_POST['filter']) ? '?status=' . urlencode($_POST['filter']) : ''));
    exit;
}

/*
|--------------------------------------------------------------------------
| REMOVE REPORTED SERVICE (delete service + resolve report)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_report'])) {

    $report_id = (int)$_POST['remove_report'];

    $stmt = $db->prepare("SELECT service_id FROM service_reports WHERE id = ?");
    $stmt->execute([$report_id]);
    $report = $stmt->fetch();

    if ($report) {
        $service_id = $report['service_id'];

        // Soft-delete the service so order/review history stays intact
        $db->prepare("UPDATE services SET status = 'deleted' WHERE id = ?")->execute([$service_id]);

        // Resolve this report and any other pending reports for the same service
        $db->prepare("
            UPDATE service_reports
            SET status = 'removed', resolved_by = ?, resolved_at = NOW()
            WHERE service_id = ? AND status = 'pending'
        ")->execute([$staff_id, $service_id]);

        flash('success', "Service #$service_id has been removed and related reports resolved.");
    } else {
        flash('error', 'Report not found.');
    }

    header('Location: /pages/staff_reports.php' . (!empty($_POST['filter']) ? '?status=' . urlencode($_POST['filter']) : ''));
    exit;
}

/*
|--------------------------------------------------------------------------
| LOAD DATA
|--------------------------------------------------------------------------
*/
$allowedStatus = ['pending', 'approved', 'removed'];

$filter = $_GET['status'] ?? 'pending';
if (!in_array($filter, $allowedStatus, true)) {
    $filter = 'all';
}

$service_id_filter = (int)($_GET['service_id'] ?? 0);

$sql = "
    SELECT
        sr.*,
        s.title AS service_title,
        s.status AS service_status,
        s.price AS service_price,
        seller.username AS seller_username,
        seller.full_name AS seller_name,
        reporter.username AS reporter_username,
        reporter.full_name AS reporter_name,
        staff.username AS resolved_by_username
    FROM service_reports sr
    JOIN services s ON s.id = sr.service_id
    JOIN users seller ON seller.id = s.seller_id
    LEFT JOIN users reporter ON reporter.id = sr.reporter_id
    LEFT JOIN staff_users staff ON staff.id = sr.resolved_by
    WHERE 1=1
";

$params = [];

if ($filter !== 'all') {
    $sql .= " AND sr.status = ? ";
    $params[] = $filter;
}

if ($service_id_filter > 0) {
    $sql .= " AND sr.service_id = ? ";
    $params[] = $service_id_filter;
}

$sql .= " ORDER BY sr.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// counts for tabs
$counts = $db->query("SELECT status, COUNT(*) c FROM service_reports GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$totalCount = array_sum($counts);

$flash_success = flash('success');
$flash_error = flash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Service Reports — CampusHelper Staff</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>
:root{
    --ink:#0e0e14;
    --cream:#f5f3ee;
    --accent:#ff5c35;
    --accent2:#3b82f6;
    --muted:#6b7280;
    --surface:#ffffff;
    --border:#e5e7eb;
}

*{ box-sizing:border-box; margin:0; padding:0; }

body{
    font-family:'DM Sans',sans-serif;
    background:var(--cream);
    color:var(--ink);
}

a{ text-decoration:none; color:inherit; }

nav{
    background:var(--ink);
    height:64px;
    display:flex;
    align-items:center;
    gap:16px;
    padding:0 32px;
}

.brand{
    font-family:'Syne',sans-serif;
    font-weight:800;
    color:#fff;
    font-size:1.3rem;
}

.brand span{ color:var(--accent); }

.nav-right{
    margin-left:auto;
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}

.btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    padding:8px 16px;
    border-radius:8px;
    border:none;
    cursor:pointer;
    font-size:.85rem;
    font-weight:600;
    font-family:'DM Sans',sans-serif;
    transition:.2s;
}

.btn-ghost{ color:#fff; background:transparent; }
.btn-ghost:hover{ background:rgba(255,255,255,.1); }
.btn-ghost.active{ background:rgba(255,255,255,.18); }

.btn-accent{ background:var(--accent); color:#fff; }
.btn-accent:hover{ background:#e04a26; }

.btn-primary{ background:var(--accent2); color:#fff; }
.btn-primary:hover{ background:#2563eb; }

.btn-danger{ background:#ef4444; color:#fff; }
.btn-danger:hover{ background:#dc2626; }

.btn-outline{ background:transparent; color:var(--ink); border:2px solid var(--border); }
.btn-outline:hover{ border-color:var(--accent2); color:var(--accent2); }

.btn-sm{ padding:6px 12px; font-size:.78rem; }

.wrap{
    max-width:1280px;
    margin:0 auto;
    padding:32px 24px;
}

h1{
    font-family:'Syne',sans-serif;
    font-weight:800;
    font-size:1.6rem;
    margin-bottom:6px;
}

.subtitle{ color:var(--muted); font-size:.9rem; margin-bottom:20px; }

.flash{
    margin-bottom:20px;
    padding:14px 18px;
    border-radius:8px;
    font-size:.9rem;
}

.flash-success{ background:#d1fae5; color:#065f46; border-left:4px solid #10b981; }
.flash-error{ background:#fee2e2; color:#991b1b; border-left:4px solid #ef4444; }

.tabs{
    display:flex;
    gap:8px;
    margin-bottom:20px;
    flex-wrap:wrap;
    align-items:center;
}

.tab{
    background:#fff;
    padding:10px 18px;
    border-radius:8px;
    color:var(--muted);
    font-weight:600;
    font-size:.85rem;
}

.tab.active{ background:var(--ink); color:#fff; }

.filter-note{
    margin-left:auto;
    font-size:.8rem;
    color:var(--muted);
    background:#fff;
    padding:10px 16px;
    border-radius:8px;
}

.filter-note a{ color:var(--accent2); font-weight:600; }

.card{
    background:#fff;
    border-radius:14px;
    overflow:hidden;
    box-shadow:0 2px 12px rgba(0,0,0,.06);
}

.table-wrap{ overflow-x:auto; }

table{ width:100%; border-collapse:collapse; }

th{
    text-align:left;
    padding:14px;
    border-bottom:2px solid var(--border);
    font-size:.75rem;
    color:var(--muted);
    white-space:nowrap;
    text-transform:uppercase;
    letter-spacing:.03em;
}

td{
    padding:14px;
    border-bottom:1px solid var(--border);
    font-size:.88rem;
    vertical-align:middle;
}

.badge{
    display:inline-block;
    padding:5px 10px;
    border-radius:999px;
    font-size:.72rem;
    font-weight:700;
    white-space:nowrap;
}

.badge-pending{ background:#fef3c7; color:#92400e; }
.badge-approved{ background:#d1fae5; color:#065f46; }
.badge-removed{ background:#fee2e2; color:#991b1b; }

.badge-active{ background:#d1fae5; color:#065f46; }
.badge-paused{ background:#fef3c7; color:#92400e; }
.badge-deleted{ background:#fee2e2; color:#991b1b; }

.empty{ text-align:center; padding:48px; color:var(--muted); }

.action-group{
    display:flex;
    gap:6px;
    flex-wrap:wrap;
}

.cell-sub{ color:var(--muted); font-size:.75rem; display:block; margin-top:2px; }

.details-text{
    max-width:240px;
    font-size:.82rem;
    color:#374151;
    white-space:pre-wrap;
}

.resolved-info{
    font-size:.75rem;
    color:var(--muted);
}
</style>
</head>

<body>

<nav>
    <a href="/" class="brand">Campus<span>Helper</span></a>

    <div class="nav-right">
        <a href="/pages/support_team.php" class="btn btn-ghost">🎫 Tickets</a>
        <a href="/pages/staff_services.php" class="btn btn-ghost">🛠 Services</a>
        <a href="/pages/staff_reports.php" class="btn btn-ghost active">🚩 Reports</a>
        <a href="/pages/staff_logout.php" class="btn btn-ghost">Logout</a>
    </div>
</nav>

<div class="wrap">

    <h1>Service Reports</h1>
    <p class="subtitle">Review flagged services reported by the community and take action.</p>

    <?php if ($flash_success): ?>
    <div class="flash flash-success"><?= e($flash_success) ?></div>
    <?php endif; ?>

    <?php if ($flash_error): ?>
    <div class="flash flash-error"><?= e($flash_error) ?></div>
    <?php endif; ?>

    <div class="tabs">
        <a href="?status=pending<?= $service_id_filter ? '&service_id='.$service_id_filter : '' ?>" class="tab <?= $filter === 'pending' ? 'active' : '' ?>">Pending (<?= (int)($counts['pending'] ?? 0) ?>)</a>
        <a href="?status=approved<?= $service_id_filter ? '&service_id='.$service_id_filter : '' ?>" class="tab <?= $filter === 'approved' ? 'active' : '' ?>">Approved (<?= (int)($counts['approved'] ?? 0) ?>)</a>
        <a href="?status=removed<?= $service_id_filter ? '&service_id='.$service_id_filter : '' ?>" class="tab <?= $filter === 'removed' ? 'active' : '' ?>">Removed (<?= (int)($counts['removed'] ?? 0) ?>)</a>
        <a href="?status=all<?= $service_id_filter ? '&service_id='.$service_id_filter : '' ?>" class="tab <?= $filter === 'all' ? 'active' : '' ?>">All (<?= (int)$totalCount ?>)</a>

        <?php if ($service_id_filter): ?>
            <div class="filter-note">
                Showing reports for service #<?= (int)$service_id_filter ?> —
                <a href="?status=<?= e($filter) ?>">clear filter</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="table-wrap">

            <?php if (empty($reports)): ?>

                <div class="empty">No reports found for this filter. 🎉</div>

            <?php else: ?>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Service</th>
                        <th>Reason</th>
                        <th>Details</th>
                        <th>Reported By</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $r): ?>
                    <tr>
                        <td>#<?= (int)$r['id'] ?></td>
                        <td style="max-width:200px;">
                            <a href="/pages/service.php?id=<?= (int)$r['service_id'] ?>" target="_blank">
                                <strong><?= e($r['service_title']) ?></strong>
                            </a>
                            <span class="cell-sub">
                                by @<?= e($r['seller_username']) ?> ·
                                <span class="badge badge-<?= e($r['service_status']) ?>"><?= ucfirst($r['service_status']) ?></span>
                            </span>
                        </td>
                        <td><?= e($r['reason']) ?></td>
                        <td class="details-text"><?= ($r['details'] !== null && $r['details'] !== '') ? e($r['details']) : '<span style="color:var(--muted)">—</span>' ?></td>
                        <td>
                            <?php if ($r['reporter_id']): ?>
                                <?= e($r['reporter_name']) ?>
                                <span class="cell-sub">@<?= e($r['reporter_username']) ?></span>
                            <?php else: ?>
                                <span style="color:var(--muted)">Guest</span>
                            <?php endif; ?>
                        </td>
                        <td><?= date('M j, Y', strtotime($r['created_at'])) ?>
                            <span class="cell-sub"><?= date('H:i', strtotime($r['created_at'])) ?></span>
                        </td>
                        <td>
                            <span class="badge badge-<?= e($r['status']) ?>"><?= ucfirst($r['status']) ?></span>
                            <?php if ($r['status'] !== 'pending' && $r['resolved_at']): ?>
                                <div class="resolved-info">
                                    by <?= e($r['resolved_by_username'] ?? 'staff') ?>
                                    on <?= date('M j', strtotime($r['resolved_at'])) ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($r['status'] === 'pending'): ?>
                            <div class="action-group">
                                <form method="POST" onsubmit="return confirm('Approve this report? No action will be taken on the service.');">
                                    <input type="hidden" name="approve_report" value="<?= (int)$r['id'] ?>">
                                    <input type="hidden" name="filter" value="<?= e($filter) ?>">
                                    <button type="submit" class="btn btn-accent btn-sm">✅ Approve</button>
                                </form>

                                <form method="POST" onsubmit="return confirm('Remove service #<?= (int)$r['service_id'] ?> from the marketplace and resolve all its pending reports?');">
                                    <input type="hidden" name="remove_report" value="<?= (int)$r['id'] ?>">
                                    <input type="hidden" name="filter" value="<?= e($filter) ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">🗑 Remove</button>
                                </form>
                            </div>
                            <?php else: ?>
                                <span style="color:var(--muted);font-size:.8rem;">No action needed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php endif; ?>
        </div>
    </div>

</div>

</body>
</html>
