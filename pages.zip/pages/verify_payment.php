<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/payments.php';
requireLogin();

$db = getDB();
$user = currentUser();
$uid = (int)$user['id'];
ensurePaymentColumns($db);

$payment_id = (int)($_GET['payment_id'] ?? 0);

// Load payment + order/service (seller only)
$stmt = $db->prepare("
    SELECT p.*, o.id AS order_id, o.service_id, o.buyer_id, o.status AS order_status,
           s.title, b.full_name AS buyer_name, b.username AS buyer_username
    FROM payments p
    JOIN orders o   ON o.id = p.order_id
    JOIN services s ON s.id = o.service_id
    JOIN users b    ON b.id = o.buyer_id
    WHERE p.id = ? AND o.seller_id = ?
");
$stmt->execute([$payment_id, $uid]);
$payment = $stmt->fetch();

if (!$payment) {
    flash('error', 'Payment not found.');
    header('Location: /pages/dashboard.php?tab=selling');
    exit;
}

/*
|--------------------------------------------------------------------------
| HANDLE VERIFY / REJECT
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    if ($payment['verify_status'] !== 'submitted') {
        flash('error', 'This payment is not awaiting verification.');
        header('Location: /pages/dashboard.php?tab=selling');
        exit;
    }

    if ($action === 'verify') {
        try {
            $db->beginTransaction();

            // Mark payment verified & paid -> NOW the receipt is valid
            $db->prepare("
                UPDATE payments
                SET status = 'success', verify_status = 'verified',
                    paid_at = NOW(), verified_at = NOW(), reject_reason = NULL
                WHERE id = ?
            ")->execute([$payment_id]);

            // Move order forward
            $db->prepare("UPDATE orders SET status = 'in_progress' WHERE id = ?")
               ->execute([(int)$payment['order_id']]);

            // Bump the service order count (kept here so it only counts
            // confirmed sales)
            $db->prepare("UPDATE services SET total_orders = total_orders + 1 WHERE id = ?")
               ->execute([(int)$payment['service_id']]);

            // Notify the buyer
            $msg = 'Your payment for "' . $payment['title'] . '" was verified. '
                 . 'Your receipt is now available in your dashboard.';
            $db->prepare("INSERT INTO messages (sender_id, receiver_id, service_id, content) VALUES (?,?,?,?)")
               ->execute([$uid, (int)$payment['buyer_id'], (int)$payment['service_id'], $msg]);

            $db->commit();
            flash('success', 'Payment verified. The buyer can now see their receipt.');
        } catch (Exception $e) {
            $db->rollBack();
            flash('error', 'Could not verify payment. Please try again.');
        }
        header('Location: /pages/dashboard.php?tab=selling');
        exit;
    }

    if ($action === 'reject') {
        $reason = trim($_POST['reason'] ?? '');
        $db->prepare("UPDATE payments SET verify_status = 'rejected', reject_reason = ? WHERE id = ?")
           ->execute([$reason ?: 'Receipt could not be confirmed.', $payment_id]);

        $msg = 'Your payment receipt for "' . $payment['title'] . '" was rejected'
             . ($reason ? ': ' . $reason : '.') . ' Please re-upload a correct receipt.';
        $db->prepare("INSERT INTO messages (sender_id, receiver_id, service_id, content) VALUES (?,?,?,?)")
           ->execute([$uid, (int)$payment['buyer_id'], (int)$payment['service_id'], $msg]);

        flash('success', 'Receipt rejected. The buyer has been asked to re-upload.');
        header('Location: /pages/dashboard.php?tab=selling');
        exit;
    }
}

$proof = $payment['proof_file'];
$isPdf = $proof && strtolower(pathinfo($proof, PATHINFO_EXTENSION)) === 'pdf';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Verify Payment — CampusHelper</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--accent2:#3b82f6;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);}
a{text-decoration:none;color:inherit;}
nav{background:var(--ink);display:flex;align-items:center;gap:16px;padding:0 32px;height:64px;}
.brand{font-family:'Syne',sans-serif;font-weight:800;font-size:1.3rem;color:#fff;}
.brand span{color:var(--accent);}
.btn-ghost{margin-left:auto;color:rgba(255,255,255,.8);background:transparent;border:none;padding:8px 16px;border-radius:8px;font-weight:600;font-size:.85rem;}
.wrap{max-width:680px;margin:30px auto;padding:0 20px;}
.card{background:var(--surface);border-radius:16px;padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.06);}
h1{font-family:'Syne',sans-serif;font-size:1.35rem;margin-bottom:6px;}
.subtitle{color:var(--muted);font-size:.9rem;margin-bottom:20px;}
.summary{background:#f5f3ee;border-radius:10px;padding:16px;margin-bottom:18px;font-size:.9rem;}
.summary .row{display:flex;justify-content:space-between;padding:6px 0;}
.summary .row b{color:var(--accent);}
.proof{border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-bottom:18px;background:#faf9f6;}
.proof img{width:100%;display:block;}
.proof iframe{width:100%;height:520px;border:none;display:block;}
.proof .nofile{padding:30px;text-align:center;color:var(--muted);}
.status-tag{display:inline-block;padding:5px 12px;border-radius:999px;font-size:.75rem;font-weight:700;margin-bottom:16px;}
.s-submitted{background:#dbeafe;color:#1e40af;}
.s-verified{background:#d1fae5;color:#065f46;}
.s-rejected{background:#fee2e2;color:#991b1b;}
.actions{display:flex;gap:10px;flex-wrap:wrap;}
.btn{padding:13px 22px;border-radius:10px;border:none;font-weight:700;font-size:.95rem;cursor:pointer;font-family:'DM Sans',sans-serif;}
.btn-verify{background:#10b981;color:#fff;flex:1;}
.btn-verify:hover{background:#059669;}
.btn-reject{background:#ef4444;color:#fff;flex:1;}
.btn-reject:hover{background:#dc2626;}
.btn-open{background:var(--accent2);color:#fff;text-decoration:none;display:inline-block;font-size:.82rem;padding:8px 14px;border-radius:8px;margin-bottom:14px;}
.reject-form{margin-top:14px;display:none;}
.reject-form textarea{width:100%;padding:10px;border:2px solid var(--border);border-radius:8px;font-family:'DM Sans',sans-serif;font-size:.9rem;resize:vertical;min-height:70px;margin-bottom:10px;}
.note{font-size:.82rem;color:var(--muted);margin-top:14px;}
</style>
</head>
<body>
<nav>
    <a href="/" class="brand">Campus<span>Helper</span></a>
    <a href="/pages/dashboard.php?tab=selling" class="btn-ghost">← Back to Sales</a>
</nav>

<div class="wrap">
    <div class="card">
        <h1>🔎 Verify Payment</h1>
        <p class="subtitle">Check the receipt against the amount below, then confirm or reject.</p>

        <span class="status-tag s-<?= e($payment['verify_status']) ?>">
            <?= ucfirst(str_replace('_', ' ', $payment['verify_status'])) ?>
        </span>

        <div class="summary">
            <div class="row"><span>Service</span><span><?= e($payment['title']) ?></span></div>
            <div class="row"><span>Buyer</span><span><?= e($payment['buyer_name']) ?> (@<?= e($payment['buyer_username']) ?>)</span></div>
            <div class="row"><span>Reference</span><span><?= e($payment['transaction_ref']) ?></span></div>
            <div class="row"><span>Expected amount</span><b><?= formatMYR($payment['amount']) ?></b></div>
        </div>

        <?php if ($proof): ?>
            <a class="btn-open" href="<?= e($proof) ?>" target="_blank" rel="noopener">Open receipt in new tab ↗</a>
            <div class="proof">
                <?php if ($isPdf): ?>
                    <iframe src="<?= e($proof) ?>" title="Payment receipt"></iframe>
                <?php else: ?>
                    <img src="<?= e($proof) ?>" alt="Payment receipt">
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="proof"><div class="nofile">The buyer has not uploaded a receipt yet.</div></div>
        <?php endif; ?>

        <?php if ($payment['verify_status'] === 'submitted'): ?>
            <div class="actions">
                <form method="POST" onsubmit="return confirm('Confirm you have received this payment? The buyer will get their receipt.');" style="flex:1;">
                    <input type="hidden" name="action" value="verify">
                    <button type="submit" class="btn btn-verify">✓ Verify Payment</button>
                </form>
                <button type="button" class="btn btn-reject" onclick="document.getElementById('rejectForm').style.display='block';this.style.display='none';">✕ Reject</button>
            </div>
            <form method="POST" class="reject-form" id="rejectForm">
                <input type="hidden" name="action" value="reject">
                <textarea name="reason" placeholder="Reason for rejection (shown to the buyer), e.g. amount doesn't match, receipt unclear..."></textarea>
                <button type="submit" class="btn btn-reject" style="width:100%;">Reject &amp; ask buyer to re-upload</button>
            </form>
        <?php elseif ($payment['verify_status'] === 'verified'): ?>
            <p class="note">✓ This payment has been verified<?= $payment['verified_at'] ? ' on ' . date('M j, Y g:i A', strtotime($payment['verified_at'])) : '' ?>.</p>
        <?php elseif ($payment['verify_status'] === 'rejected'): ?>
            <p class="note">✕ You rejected this receipt. Waiting for the buyer to upload a new one.</p>
        <?php else: ?>
            <p class="note">Waiting for the buyer to upload their payment receipt.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
