<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/payments.php';

requireLogin();

$db = getDB();
$user = currentUser();
ensurePaymentColumns($db);

/*
|--------------------------------------------------------------------------
| CREATE ORDER
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['confirm'])) {

    $service_id = (int)($_POST['service_id'] ?? 0);
    $requirements = trim($_POST['requirements'] ?? '');

    // Get service
    $svc = $db->prepare("
        SELECT *
        FROM services
        WHERE id = ? AND status = 'active'
    ");

    $svc->execute([$service_id]);
    $svc = $svc->fetch();

    // Service validation
    if (!$svc) {

        flash('error', 'Service not found.');

        header('Location: /pages/');
        exit;
    }

    // Prevent ordering own service
    if ($svc['seller_id'] == $user['id']) {

        flash('error', 'You cannot order your own service.');

        header('Location: /pages/service.php?id=' . $service_id);
        exit;
    }

    // Fees
    $platform_fee = round($svc['price'] * 0.05, 2);
    $seller_earnings = $svc['price'] - $platform_fee;

    // Delivery date
    $delivery_date = date(
        'Y-m-d',
        strtotime('+' . (int)$svc['delivery_days'] . ' days')
    );

    // Create order
    $stmt = $db->prepare("
        INSERT INTO orders
        (
            service_id,
            buyer_id,
            seller_id,
            amount,
            platform_fee,
            seller_earnings,
            requirements,
            delivery_date,
            status
        )
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $service_id,
        $user['id'],
        $svc['seller_id'],
        $svc['price'],
        $platform_fee,
        $seller_earnings,
        $requirements,
        $delivery_date,
        'pending'
    ]);

    $order_id = $db->lastInsertId();

    // Redirect to payment confirmation page
    header('Location: /pages/order.php?confirm=1&order_id=' . $order_id);
    exit;
}

/*
|--------------------------------------------------------------------------
| LOAD ORDER
|--------------------------------------------------------------------------
*/
$order_id = (int)($_GET['order_id'] ?? 0);

$order = $db->prepare("
    SELECT
        o.*,
        s.title,
        s.delivery_days,
        s.total_orders,
        u.full_name as seller_name,
        u.username as seller_username,
        u.qr_code as seller_qr
    FROM orders o
    JOIN services s ON s.id = o.service_id
    JOIN users u ON u.id = o.seller_id
    WHERE o.id = ? AND o.buyer_id = ?
");

$order->execute([$order_id, $user['id']]);
$order = $order->fetch();

if (!$order) {

    flash('error', 'Order not found.');

    header('Location: /pages/');
    exit;
}

/*
|--------------------------------------------------------------------------
| PROCESS PAYMENT
|--------------------------------------------------------------------------
*/
if (isset($_GET['pay'])) {

    // Prevent duplicate payment
    if ($order['status'] !== 'pending') {

        flash('error', 'Order already processed.');

        header('Location: /pages/dashboard.php?tab=buying');
        exit;
    }

    try {

        $db->beginTransaction();

        // If a payment row already exists for this order (e.g. buyer came
        // back), reuse it instead of creating a duplicate.
        $existingPay = $db->prepare("SELECT id FROM payments WHERE order_id = ? LIMIT 1");
        $existingPay->execute([$order_id]);
        $existing_payment_id = $existingPay->fetchColumn();

        if ($existing_payment_id) {
            $payment_id = $existing_payment_id;
        } else {
            // Generate transaction reference
            $transaction_ref = 'CH-' . strtoupper(uniqid());

            /*
            |--------------------------------------------------------------
            | CREATE PENDING PAYMENT (awaiting proof of payment)
            |--------------------------------------------------------------
            | The buyer has scanned the QR and clicked "I've Paid", but the
            | money has not been confirmed yet. We record the payment as
            | pending and ask the buyer to upload their bank/e-wallet
            | receipt so the seller can verify the transfer. Only after the
            | seller verifies does the order move to in_progress and a
            | CampusHelper receipt get issued.
            */
            $payment = $db->prepare("
                INSERT INTO payments
                (
                    order_id,
                    payer_id,
                    amount,
                    method,
                    transaction_ref,
                    status,
                    verify_status,
                    created_at
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            $payment->execute([
                $order_id,
                $user['id'],
                $order['amount'],
                'maybank_qr',
                $transaction_ref,
                'pending',
                'awaiting_proof'
            ]);

            $payment_id = $db->lastInsertId();
        }

        $db->commit();

        /*
        |------------------------------------------------------------------
        | ASK BUYER FOR PROOF OF PAYMENT
        |------------------------------------------------------------------
        */
        header('Location: /pages/upload_proof.php?payment_id=' . $payment_id);

        exit;

    } catch (Exception $e) {

        $db->rollBack();

        flash('error', 'Could not start payment. Please try again.');

        header(
            'Location: /pages/order.php?confirm=1&order_id=' . $order_id
        );

        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Payment — CampusHelper</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<style>
*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    font-family:'DM Sans',sans-serif;
    background:#f5f3ee;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:32px 16px;
}

.card{
    background:#fff;
    border-radius:16px;
    padding:36px;
    max-width:520px;
    width:100%;
    box-shadow:0 8px 40px rgba(0,0,0,.1);
}

.brand{
    font-family:'Syne',sans-serif;
    font-weight:800;
    font-size:1.2rem;
    color:#0e0e14;
    margin-bottom:24px;
    display:block;
    text-decoration:none;
}

.brand span{
    color:#ff5c35;
}

h1{
    font-family:'Syne',sans-serif;
    font-size:1.4rem;
    font-weight:700;
    margin-bottom:6px;
}

.subtitle{
    color:#6b7280;
    font-size:.9rem;
    margin-bottom:24px;
}

.order-box{
    background:#f5f3ee;
    border-radius:10px;
    padding:16px;
    margin-bottom:24px;
}

.order-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:8px 0;
    border-bottom:1px solid #e5e7eb;
    font-size:.9rem;
}

.order-row:last-child{
    border:none;
    font-weight:700;
    font-size:1rem;
}

.total-row{
    background:#0e0e14;
    color:#fff;
    border-radius:8px;
    padding:14px 16px;
    display:flex;
    justify-content:space-between;
    font-weight:700;
    font-size:1.1rem;
    margin-bottom:20px;
}

.total-row span{
    color:#ff5c35;
}

.payment-methods{
    display:grid;
    grid-template-columns:1fr 1fr 1fr;
    gap:10px;
    margin-bottom:20px;
}

.pm{
    border:2px solid #e5e7eb;
    border-radius:10px;
    padding:14px;
    text-align:center;
    cursor:pointer;
    transition:all .2s;
}

.pm.active,
.pm:hover{
    border-color:#3b82f6;
    background:#eff6ff;
}

.pm .pm-icon{
    font-size:1.6rem;
    margin-bottom:6px;
}

.pm .pm-name{
    font-size:.8rem;
    font-weight:500;
}

.btn{
    display:block;
    width:100%;
    padding:14px;
    border-radius:10px;
    border:none;
    background:#ff5c35;
    color:#fff;
    font-family:'DM Sans',sans-serif;
    font-weight:700;
    font-size:1rem;
    cursor:pointer;
    transition:background .2s;
    text-align:center;
    text-decoration:none;
}

.btn:hover{
    background:#e04a26;
}

.btn-back{
    background:transparent;
    color:#6b7280;
    border:2px solid #e5e7eb;
    margin-top:10px;
}

.btn-back:hover{
    border-color:#6b7280;
    background:#f5f3ee;
}

.pm.pm-qr{
    border-color:#ff5c35;
    background:#fff7f5;
}

.pm.pm-qr.active,
.pm.pm-qr:hover{
    border-color:#ff5c35;
    background:#ffe8e2;
}

.secure{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    color:#6b7280;
    font-size:.8rem;
    margin-top:14px;
}

/* QR Code Panel */
.qr-panel{
    display:none;
    background:#fff7f5;
    border:2px solid #ff5c35;
    border-radius:14px;
    padding:24px 20px;
    margin-bottom:20px;
    text-align:center;
    animation:fadeIn .3s ease;
}

.qr-panel.visible{
    display:block;
}

@keyframes fadeIn{
    from{opacity:0;transform:translateY(-8px);}
    to{opacity:1;transform:translateY(0);}
}

.qr-panel .qr-title{
    font-family:'Syne',sans-serif;
    font-weight:700;
    font-size:1rem;
    margin-bottom:4px;
    color:#0e0e14;
}

.qr-panel .qr-subtitle{
    font-size:.8rem;
    color:#6b7280;
    margin-bottom:16px;
}

.qr-panel img.qr-img{
    width:200px;
    height:200px;
    object-fit:contain;
    border-radius:8px;
    border:4px solid #fff;
    box-shadow:0 4px 16px rgba(0,0,0,.12);
    margin-bottom:12px;
}

.qr-panel .qr-name{
    font-weight:700;
    font-size:.95rem;
    color:#0e0e14;
    margin-bottom:2px;
}

.qr-panel .qr-bank{
    font-size:.8rem;
    color:#6b7280;
    margin-bottom:12px;
}

.qr-panel .qr-amount{
    background:#0e0e14;
    color:#fff;
    border-radius:8px;
    padding:10px 16px;
    font-weight:700;
    font-size:1.05rem;
    display:inline-block;
    margin-bottom:12px;
}

.qr-panel .qr-amount span{
    color:#ff5c35;
}

.qr-panel .qr-note{
    font-size:.78rem;
    color:#6b7280;
    line-height:1.5;
}

.qr-panel .qr-steps{
    text-align:left;
    background:#fff;
    border-radius:10px;
    padding:14px 16px;
    margin-top:14px;
    font-size:.82rem;
    color:#374151;
    line-height:2;
}

.qr-panel .qr-steps b{
    color:#ff5c35;
}
</style>
</head>

<body>

<div class="card">

    <a href="/pages/" class="brand">
        Campus<span>Helper</span>
    </a>

    <h1>💳 Complete Payment</h1>

    <p class="subtitle">
        Review your order before paying
    </p>

    <div class="order-box">

        <div class="order-row">
            <span>Service</span>
            <span style="max-width:220px;text-align:right;font-size:.85rem">
                <?= e($order['title']) ?>
            </span>
        </div>

        <div class="order-row">
            <span>Seller</span>
            <span><?= e($order['seller_name']) ?></span>
        </div>

        <div class="order-row">
            <span>Delivery by</span>
            <span><?= date('M j, Y', strtotime($order['delivery_date'])) ?></span>
        </div>

        <div class="order-row">
            <span>Platform Fee (5%)</span>
            <span>+ <?= formatMYR($order['platform_fee']) ?></span>
        </div>

        <div class="order-row">
            <span>Total</span>
            <span style="color:#ff5c35">
                <?= formatMYR($order['amount']) ?>
            </span>
        </div>

    </div>

    <div class="total-row">
        Total to Pay
        <span><?= formatMYR($order['amount']) ?></span>
    </div>

    <p style="font-size:.85rem;font-weight:500;margin-bottom:12px;">
        Select Payment Method
    </p>

    <div class="payment-methods">

        <?php
        foreach([
            ['💳','Credit / Debit Card'],
            ['🏦','Online Banking'],
            ['📱','Touch \'n Go'],
            ['💰','CampusHelper Credits'],
            ['🏧','Maybank QR','qr']
        ] as $pm):
            $icon = $pm[0];
            $name = $pm[1];
            $isQR = isset($pm[2]) && $pm[2] === 'qr';
        ?>

        <div class="pm <?= $isQR ? 'pm-qr' : '' ?>" onclick="selectPM(this, <?= $isQR ? 'true' : 'false' ?>)">
            <div class="pm-icon"><?= $icon ?></div>
            <div class="pm-name"><?= $name ?></div>
        </div>

        <?php endforeach; ?>

    </div>

    <!-- QR Payment Panel -->
    <div class="qr-panel" id="qrPanel">
            <?php if (!empty($order['seller_qr'])): ?>
                <div class="qr-title">📲 Scan to Pay — Seller's QR</div>
                <div class="qr-subtitle">Open your banking app and scan the seller's QR code below</div>
                <img class="qr-img" src="<?= e($order['seller_qr']) ?>" alt="Seller payment QR">
                <div class="qr-name"><?= e($order['seller_name']) ?></div>
                <div class="qr-bank">Seller provided QR</div>
            <?php else: ?>
                <div class="qr-title">📲 Scan to Pay via Maybank QR</div>
                <div class="qr-subtitle">Open your Maybank app and scan the QR code below</div>
                <img
                    class="qr-img"
                    src="<?php
                        $qrPath = __DIR__ . '/../assets/maybank_qr.jpg';
                        if (file_exists($qrPath)) {
                            echo '/assets/maybank_qr.jpg';
                        } else {
                            echo '';
                        }
                    ?>"
                    alt="Maybank QR Code"
                >
                <div class="qr-name">CampusHelper</div>
                <div class="qr-bank">Maybank · QR Pay</div>
            <?php endif; ?>
        <div class="qr-amount">
            Amount: <span><?= formatMYR($order['amount']) ?></span>
        </div>
        <div class="qr-note">⚠️ Please transfer the exact amount shown above.</div>
        <div class="qr-steps">
            <b>How to pay:</b><br>
            1. Open <b>Maybank2u</b> or <b>MAE</b> app<br>
            2. Tap <b>Scan &amp; Pay</b> or QR icon<br>
            3. Scan the QR code above<br>
            4. Enter amount: <b><?= formatMYR($order['amount']) ?></b><br>
            5. Confirm &amp; click <b>"I've Paid"</b> below
        </div>
    </div>

    <a
        id="payBtn"
        href="/pages/order.php?confirm=1&order_id=<?= $order_id ?>&pay=1"
        class="btn"
    >
        🔒 Pay <?= formatMYR($order['amount']) ?>
    </a>

    <a href="/pages/" class="btn btn-back">
        ← Cancel
    </a>

    <div class="secure">
        🔒 Secured by CampusHelper Payment Gateway
    </div>

</div>

<script>

var isQRSelected = false;

function selectPM(el, isQR){

    document
        .querySelectorAll('.pm')
        .forEach(e => e.classList.remove('active'));

    el.classList.add('active');

    isQRSelected = !!isQR;
    var qrPanel = document.getElementById('qrPanel');
    if (isQR) {
        qrPanel.classList.add('visible');
    } else {
        qrPanel.classList.remove('visible');
    }
}

document.querySelector('.pm').classList.add('active');

// Override pay button for QR flow
document.getElementById('payBtn').addEventListener('click', function(e){
    if (isQRSelected) {
        e.preventDefault();
        if (confirm('Have you completed the QR payment of <?= formatMYR($order['amount']) ?>?\n\nClick OK to upload your payment receipt so the seller can verify it.')) {
            window.location.href = this.href;
        }
    } else {
        // Non-QR methods are not supported yet
        e.preventDefault();
        alert('Only QR payments are supported right now. Please select the QR option and follow the instructions.');
    }
});

</script>

</body>
</html>