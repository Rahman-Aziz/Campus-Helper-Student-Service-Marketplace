<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireLogin();

$db = getDB();
$user = currentUser();
$uid = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $university = trim($_POST['university'] ?? '');
    $bio       = trim($_POST['bio'] ?? '');

    if (!$full_name || !$username || !$email) {
        flash('error', 'Full name, username, and email are required.');
    } else {
        $check = $db->prepare("SELECT id FROM users WHERE (email = ? OR username = ?) AND id != ?");
        $check->execute([$email, $username, $uid]);
        if ($check->fetch()) {
            flash('error', 'The email or username is already taken.');
        } else {
                // Ensure users table has qr_code column (best-effort)
                try {
                    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS qr_code VARCHAR(255) DEFAULT NULL");
                } catch (Exception $e) {
                    // ignore if ALTER not supported or fails
                }

                // Handle QR upload if provided
                $qr_code = $user['qr_code'] ?? null;
                if (!empty($_FILES['qr_code']['name']) && $_FILES['qr_code']['error'] === UPLOAD_ERR_OK) {
                    $type = mime_content_type($_FILES['qr_code']['tmp_name']);
                    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
                    if (!isset($allowed[$type])) {
                        flash('error', 'QR code must be a JPG, PNG or WEBP image.');
                    } elseif ($_FILES['qr_code']['size'] > 3 * 1024 * 1024) {
                        flash('error', 'QR image is too large (max 3 MB).');
                    } else {
                        $dir = __DIR__ . '/../uploads/qr';
                        if (!is_dir($dir)) mkdir($dir, 0755, true);
                        $fname = 'qr_' . $uid . '_' . time() . '.' . $allowed[$type];
                        if (move_uploaded_file($_FILES['qr_code']['tmp_name'], $dir . '/' . $fname)) {
                            $qr_code = '/uploads/qr/' . $fname;
                        } else {
                            flash('error', 'Could not save the QR image. Check folder permissions.');
                        }
                    }
                }

                $stmt = $db->prepare("UPDATE users SET full_name = ?, username = ?, email = ?, university = ?, bio = ?, qr_code = ? WHERE id = ?");
                $stmt->execute([$full_name, $username, $email, $university, $bio, $qr_code, $uid]);
            $_SESSION['user'] = array_merge($user, [
                'full_name' => $full_name,
                'username' => $username,
                'email' => $email,
                'university' => $university,
                    'bio' => $bio,
                    'qr_code' => $qr_code,
            ]);
            flash('success', 'Profile updated successfully.');
            header('Location: /pages/profile.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Profile — CampusHelper</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0e0e14;--cream:#f5f3ee;--accent:#ff5c35;--accent2:#3b82f6;--surface:#fff;--muted:#6b7280;--border:#e5e7eb;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);}
a{text-decoration:none;color:inherit;}
nav{background:var(--ink);display:flex;align-items:center;gap:16px;padding:0 32px;height:64px;}
.brand{font-family:'Syne',sans-serif;font-weight:800;font-size:1.3rem;color:#fff;}
.brand span{color:var(--accent);}
.btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 18px;border-radius:8px;font-family:'DM Sans',sans-serif;font-weight:500;font-size:.9rem;cursor:pointer;border:none;transition:all .2s;background:var(--accent);color:#fff;width:100%;}
.btn:hover{background:#e04a26;}
.wrap{max-width:720px;margin:40px auto;padding:0 20px;}
.card{background:var(--surface);border-radius:16px;padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.06);}
.title{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:700;margin-bottom:6px;}
.subtitle{color:var(--muted);margin-bottom:24px;font-size:.9rem;}
.form-group{margin-bottom:16px;}
.form-label{display:block;font-size:.85rem;font-weight:500;margin-bottom:6px;}
.form-input,.form-textarea{width:100%;padding:12px 14px;border:2px solid var(--border);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:.9rem;outline:none;transition:border .2s;background:#fff;}
.form-input:focus,.form-textarea:focus{border-color:var(--accent2);}
.form-textarea{min-height:120px;resize:vertical;}
.flash{padding:12px 18px;border-radius:8px;background:#d1fae5;color:#065f46;margin-bottom:18px;font-size:.9rem;border-left:4px solid #10b981;}
</style>
</head>
<body>
<nav>
    <a href="/index.php/" class="brand">Campus<span>Helper</span></a>
</nav>

<div class="wrap">
    <div class="card">
        <?php if ($msg = flash('success')): ?>
            <div class="flash"><?= e($msg) ?></div>
        <?php endif; ?>

        <div class="title">👤 Update Profile</div>
        <div class="subtitle">Manage your account information</div>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-input" value="<?= e($user['full_name']) ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-input" value="<?= e($user['username']) ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-input" value="<?= e($user['email']) ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">University</label>
                <input type="text" name="university" class="form-input" value="<?= e($user['university']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label">Bio</label>
                <textarea name="bio" class="form-textarea"><?= e($user['bio']) ?></textarea>
            </div>

            <div class="form-group">
                <div class="section-title">💳 Payment QR Code</div>
                <?php if (!empty($user['qr_code'])): ?>
                    <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
                        <img src="<?= e($user['qr_code']) ?>" alt="Your payment QR" style="width:120px;height:120px;object-fit:contain;border-radius:8px;border:1px solid var(--border);background:#fff;padding:6px">
                        <div>
                            <strong>Your QR is set.</strong>
                            <div style="color:var(--muted);font-size:.85rem">Upload a new image below to replace it.</div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="qr-none">No QR uploaded yet. Buyers won't be able to pay you until you add one.</div>
                <?php endif; ?>
                <label class="form-label">Upload QR Image (JPG / PNG / WEBP, max 3 MB)</label>
                <input type="file" name="qr_code" class="form-input" accept="image/png,image/jpeg,image/webp">
                <div class="hint" style="font-size:.85rem;color:var(--muted);margin-top:6px">Tip: take a screenshot of your "Receive" QR in your banking/e-wallet app and upload it here.</div>
            </div>

            <button class="btn">Save Changes</button>
        </form>
    </div>
</div>
</body>
</html>
