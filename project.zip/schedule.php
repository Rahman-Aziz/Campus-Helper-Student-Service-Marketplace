<?php
session_start();
require_once '../includes/db.php';

// Pull from DB
$result   = $conn->query("SELECT * FROM schedule ORDER BY FIELD(day,'Monday','Tuesday','Wednesday','Thursday','Friday'), start_time ASC");
$schedule = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) $schedule[] = $row;
}
$days = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Schedule — CampusHelper</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<nav class="navbar">
  <div class="nav-container">
    <a href="../index.php" class="nav-logo"><i class="fas fa-graduation-cap" style="color:var(--accent)"></i> Campus<span>Helper</span></a>
    <ul class="nav-links">
      <li><a href="../index.php">Home</a></li>
      <li><a href="schedule.php" class="active">Schedule</a></li>
      <li><a href="resources.php">Resources</a></li>
      <li><a href="events.php">Events</a></li>
      <?php if (isset($_SESSION['user'])): ?>
        <li><a href="logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="login.php" class="btn-nav">Login</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<div class="inner-page">
  <div class="container">
    <div class="page-header">
      <h1><i class="fas fa-calendar-alt" style="color:var(--primary);margin-right:10px;"></i>Class Schedule</h1>
      <p>Your weekly timetable — click a day tab to filter.</p>
    </div>

    <!-- Day Tabs -->
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:28px;" id="day-tabs">
      <button class="day-tab active" data-day="all">All Days</button>
      <?php foreach ($days as $d): ?>
        <button class="day-tab" data-day="<?= $d ?>"><?= $d ?></button>
      <?php endforeach; ?>
    </div>

    <div class="card" style="overflow-x:auto;">
      <table class="schedule-table" id="schedule-table">
        <thead>
          <tr>
            <th>Day</th>
            <th>Start</th>
            <th>End</th>
            <th>Subject</th>
            <th>Code</th>
            <th>Lecturer</th>
            <th>Location</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($schedule as $row): ?>
          <tr data-day="<?= $row['day'] ?>">
            <td><span class="badge badge-blue"><?= $row['day'] ?></span></td>
            <td><?= $row['start_time'] ?></td>
            <td><?= $row['end_time'] ?></td>
            <td><strong><?= htmlspecialchars($row['subject']) ?></strong></td>
            <td><span class="badge badge-orange"><?= $row['subject_code'] ?></span></td>
            <td><?= htmlspecialchars($row['lecturer']) ?></td>
            <td><i class="fas fa-map-marker-alt" style="color:var(--primary);margin-right:6px;"></i><?= htmlspecialchars($row['room']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<style>
.day-tab {
  padding: 9px 18px; border-radius: 8px;
  background: var(--surface); border: 1px solid var(--border);
  color: var(--text-muted); font-family: 'DM Sans',sans-serif;
  font-size: 0.88rem; font-weight: 600; cursor: pointer;
  transition: 0.2s;
}
.day-tab.active { background: var(--primary); color: #fff; border-color: var(--primary); }
.day-tab:hover:not(.active) { background: var(--surface2); color: var(--text); }
</style>

<script>
document.querySelectorAll('.day-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.day-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const day = btn.dataset.day;
    document.querySelectorAll('#schedule-table tbody tr').forEach(row => {
      row.style.display = (day === 'all' || row.dataset.day === day) ? '' : 'none';
    });
  });
});
</script>
<script src="../js/main.js"></script>
</body>
</html>
