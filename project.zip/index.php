<?php
session_start();
$pageTitle = "Campus Helper";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?= $pageTitle ?></title>
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="nav-container">
    <a href="index.php" class="nav-logo">
      <span class="logo-icon"><i class="fas fa-graduation-cap"></i></span>
      Campus<span>Helper</span>
    </a>
    <ul class="nav-links">
      <li><a href="index.php" class="active">Home</a></li>
      <li><a href="pages/schedule.php">Schedule</a></li>
      <li><a href="pages/resources.php">Resources</a></li>
      <li><a href="pages/events.php">Events</a></li>
      <li><a href="pages/map.php">Campus Map</a></li>
      <?php if (isset($_SESSION['user'])): ?>
        <li><a href="pages/dashboard.php" class="btn-nav">Dashboard</a></li>
        <li><a href="pages/logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="pages/login.php" class="btn-nav">Login</a></li>
      <?php endif; ?>
    </ul>
    <button class="hamburger" id="hamburger"><i class="fas fa-bars"></i></button>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-content">
    <span class="hero-badge">Your Campus, Simplified</span>
    <h1>Everything You Need<br><span>In One Place</span></h1>
    <p>Schedules, resources, events, and maps — all designed to make your campus life easier.</p>
    <div class="hero-buttons">
      <a href="pages/register.php" class="btn-primary">Get Started <i class="fas fa-arrow-right"></i></a>
      <a href="pages/resources.php" class="btn-secondary">Explore Resources</a>
    </div>
  </div>
  <div class="hero-visual">
    <div class="floating-card card-1"><i class="fas fa-calendar-check"></i> Schedule Ready</div>
    <div class="floating-card card-2"><i class="fas fa-map-marker-alt"></i> Room Found</div>
    <div class="floating-card card-3"><i class="fas fa-bell"></i> Event Alert</div>
    <div class="hero-circle"></div>
  </div>
</section>

<!-- FEATURES -->
<section class="features">
  <div class="container">
    <div class="section-header">
      <h2>What Can We Help With?</h2>
      <p>Built by students, for students. Every feature solves a real campus problem.</p>
    </div>
    <div class="features-grid">
      <a href="pages/schedule.php" class="feature-card">
        <div class="feature-icon"><i class="fas fa-calendar-alt"></i></div>
        <h3>Class Schedule</h3>
        <p>View and manage your weekly timetable with room numbers and lecturer info.</p>
        <span class="feature-link">Open Schedule <i class="fas fa-chevron-right"></i></span>
      </a>
      <a href="pages/resources.php" class="feature-card">
        <div class="feature-icon"><i class="fas fa-book-open"></i></div>
        <h3>Study Resources</h3>
        <p>Access lecture notes, past papers, and curated links for every subject.</p>
        <span class="feature-link">Browse Resources <i class="fas fa-chevron-right"></i></span>
      </a>
      <a href="pages/events.php" class="feature-card">
        <div class="feature-icon"><i class="fas fa-star"></i></div>
        <h3>Campus Events</h3>
        <p>Stay updated on talks, fairs, clubs, and social events happening on campus.</p>
        <span class="feature-link">See Events <i class="fas fa-chevron-right"></i></span>
      </a>
      <a href="pages/map.php" class="feature-card">
        <div class="feature-icon"><i class="fas fa-map"></i></div>
        <h3>Campus Map</h3>
        <p>Find classrooms, labs, cafeterias, and facilities without getting lost.</p>
        <span class="feature-link">Open Map <i class="fas fa-chevron-right"></i></span>
      </a>
      <a href="pages/announcements.php" class="feature-card">
        <div class="feature-icon"><i class="fas fa-bullhorn"></i></div>
        <h3>Announcements</h3>
        <p>Never miss important notices from your faculty or student council.</p>
        <span class="feature-link">View Notices <i class="fas fa-chevron-right"></i></span>
      </a>
      <a href="pages/contact.php" class="feature-card">
        <div class="feature-icon"><i class="fas fa-headset"></i></div>
        <h3>Help & Support</h3>
        <p>Contact admin, IT support, or find FAQs to solve your campus problems fast.</p>
        <span class="feature-link">Get Help <i class="fas fa-chevron-right"></i></span>
      </a>
    </div>
  </div>
</section>

<!-- STATS -->
<section class="stats-section">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item">
        <span class="stat-num">2,400+</span>
        <span class="stat-label">Students Using</span>
      </div>
      <div class="stat-item">
        <span class="stat-num">150+</span>
        <span class="stat-label">Resources Available</span>
      </div>
      <div class="stat-item">
        <span class="stat-num">40+</span>
        <span class="stat-label">Campus Events</span>
      </div>
      <div class="stat-item">
        <span class="stat-num">24/7</span>
        <span class="stat-label">Always Accessible</span>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="index.php" class="nav-logo"><i class="fas fa-graduation-cap"></i> Campus<span>Helper</span></a>
        <p>Making campus life simpler, one feature at a time.</p>
      </div>
      <div class="footer-links">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="pages/schedule.php">Schedule</a></li>
          <li><a href="pages/resources.php">Resources</a></li>
          <li><a href="pages/events.php">Events</a></li>
          <li><a href="pages/map.php">Campus Map</a></li>
        </ul>
      </div>
      <div class="footer-links">
        <h4>Account</h4>
        <ul>
          <li><a href="pages/login.php">Login</a></li>
          <li><a href="pages/register.php">Register</a></li>
          <li><a href="pages/dashboard.php">Dashboard</a></li>
          <li><a href="pages/contact.php">Support</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; <?= date('Y') ?> CampusHelper. Built for students.</p>
    </div>
  </div>
</footer>

<script src="js/main.js"></script>
</body>
</html>
