<?php
session_start();
require_once '../includes/db.php';

$result    = $conn->query("SELECT * FROM resources ORDER BY created_at DESC");
$resources = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) $resources[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Resources — CampusHelper</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<nav class="navbar">
  <div class="nav-container">
    <a href="../index.php" class="nav-logo"><i class="fas fa-graduation-cap" style="color:var(--accent)"></i> Campus<span>Helper</span></a>
    <ul class="nav-links">
      <li><a href="../index.php">Home</a></li>
      <li><a href="schedule.php">Schedule</a></li>
      <li><a href="resources.php" class="active">Resources</a></li>
      <li><a href="events.php">Events</a></li>
      <?php if (isset($_SESSION['user'])): ?>
        <li><a href="logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="login.php" class="btn-nav">Login</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<div class="inner-page">
  <div class="container">
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
      <div>
        <h1><i class="fas fa-book-open" style="color:var(--primary);margin-right:10px;"></i>Study Resources</h1>
        <p>Lecture notes, past papers, slides, and more.</p>
      </div>
      <input type="text" id="search-res" placeholder="🔍  Search resources..." style="padding:10px 16px; background:var(--surface); border:1px solid var(--border); border-radius:10px; color:var(--text); font-family:'DM Sans',sans-serif; width:240px; outline:none;"/>
    </div>

    <div class="card" style="overflow-x:auto;">
      <table class="schedule-table" id="res-table">
        <thead>
          <tr>
            <th>Resource Name</th>
            <th>Subject</th>
            <th>Type</th>
            <th>Uploaded By</th>
            <th>Description</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($resources as $r):
            $typeClass = match($r['file_type']) {
              'PDF'   => 'badge-blue',
              'Video' => 'badge-orange',
              'XLSX'  => 'badge-green',
              default => 'badge-blue'
            };
            $icon = match($r['file_type']) {
              'PDF'   => 'fa-file-pdf',
              'PPTX'  => 'fa-file-powerpoint',
              'Video' => 'fa-video',
              'XLSX'  => 'fa-file-excel',
              'ZIP'   => 'fa-file-archive',
              default => 'fa-file'
            };
          ?>
          <tr>
            <td><i class="fas <?= $icon ?>" style="color:var(--primary);margin-right:8px;"></i><strong><?= htmlspecialchars($r['title']) ?></strong></td>
            <td><span class="badge badge-blue"><?= htmlspecialchars($r['subject_code']) ?></span></td>
            <td><span class="badge <?= $typeClass ?>"><?= $r['file_type'] ?></span></td>
            <td><?= htmlspecialchars($r['uploaded_by']) ?></td>
            <td style="color:var(--text-muted); font-size:0.88rem; max-width:260px;"><?= htmlspecialchars($r['description']) ?></td>
            <td>
              <?php if (isset($_SESSION['user'])): ?>
                <a href="<?= htmlspecialchars($r['file_path']) ?>" class="btn-primary" style="padding:7px 16px; font-size:0.82rem;">Download</a>
              <?php else: ?>
                <a href="login.php" class="btn-secondary" style="padding:7px 16px; font-size:0.82rem;">Login to Download</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
document.getElementById('search-res').addEventListener('input', function() {
  const q = this.value.toLowerCase();
  document.querySelectorAll('#res-table tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});
</script>
<script src="../js/main.js"></script>
</body>
</html>
