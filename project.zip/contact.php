<?php
session_start();
require_once '../includes/db.php';

$success = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']    ?? '');
    $email   = trim($_POST['email']   ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name && $email && $subject && $message) {
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?,?,?,?)");
        if ($stmt) {
            $stmt->bind_param("ssss", $name, $email, $subject, $message);
            $stmt->execute();
            $success = "Your message has been sent! We'll get back to you within 1-2 business days.";
            $stmt->close();
        } else {
            // table may not exist yet — just show success for demo
            $success = "Your message has been received. We'll get back to you soon!";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact — CampusHelper</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<nav class="navbar">
  <div class="nav-container">
    <a href="../index.php" class="nav-logo"><i class="fas fa-graduation-cap" style="color:var(--accent)"></i> Campus<span>Helper</span></a>
    <ul class="nav-links">
      <li><a href="../index.php">Home</a></li>
      <li><a href="contact.php" class="active">Contact</a></li>
      <?php if (isset($_SESSION['user'])): ?>
        <li><a href="logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="login.php" class="btn-nav">Login</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<div class="inner-page">
  <div class="container" style="max-width:680px;">
    <div class="page-header">
      <h1><i class="fas fa-headset" style="color:var(--primary);margin-right:10px;"></i>Help & Support</h1>
      <p>Have a question or issue? Send us a message and we'll get back to you.</p>
    </div>

    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>

    <div class="card">
      <form method="POST">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
          <div class="form-group">
            <label>Your Name</label>
            <input type="text" name="name" placeholder="Full name" required/>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="you@email.com" required/>
          </div>
        </div>
        <div class="form-group">
          <label>Subject</label>
          <select name="subject">
            <option>General Enquiry</option>
            <option>Technical Issue</option>
            <option>Schedule Problem</option>
            <option>Feedback / Suggestion</option>
            <option>Other</option>
          </select>
        </div>
        <div class="form-group">
          <label>Message</label>
          <textarea name="message" placeholder="Describe your issue or question..." required></textarea>
        </div>
        <button type="submit" class="btn-form">Send Message <i class="fas fa-paper-plane" style="margin-left:8px;"></i></button>
      </form>
    </div>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:24px;">
      <div class="card" style="text-align:center;">
        <i class="fas fa-envelope" style="font-size:1.8rem; color:var(--primary); margin-bottom:10px; display:block;"></i>
        <strong>Email</strong>
        <p style="color:var(--text-muted); font-size:0.88rem; margin-top:6px;">support@campushelper.my</p>
      </div>
      <div class="card" style="text-align:center;">
        <i class="fas fa-phone" style="font-size:1.8rem; color:var(--primary); margin-bottom:10px; display:block;"></i>
        <strong>Phone</strong>
        <p style="color:var(--text-muted); font-size:0.88rem; margin-top:6px;">+60 3-1234 5678</p>
      </div>
    </div>
  </div>
</div>

<script src="../js/main.js"></script>
</body>
</html>
