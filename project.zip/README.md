# Campus Helper — Setup Guide

## Requirements
- XAMPP or WAMP (Apache + PHP 8+ + MySQL)
- Visual Studio Code
- Web browser

---

## Folder Structure

```
campus helper project/
├── index.php              ← Homepage
├── database.sql           ← Run this first!
├── css/
│   └── style.css
├── js/
│   └── main.js
├── includes/
│   └── db.php             ← Database config
└── pages/
    ├── login.php
    ├── register.php
    ├── logout.php
    ├── dashboard.php
    ├── schedule.php
    ├── resources.php
    ├── events.php
    ├── announcements.php
    ├── contact.php
    └── map.php
```

---

## Step-by-Step Setup

### 1. Copy project to XAMPP
Place the folder inside:
```
C:\xampp\htdocs\campus helper project\
```

### 2. Start XAMPP
Open XAMPP Control Panel → Start **Apache** and **MySQL**

### 3. Create the database
1. Open browser → go to `http://localhost/phpmyadmin`
2. Click **Import** tab
3. Choose `database.sql` from this project folder
4. Click **Go**

### 4. Configure DB connection
Open `includes/db.php` and update:
```php
define('DB_USER', 'root');    // your MySQL username
define('DB_PASS', '');        // your MySQL password (blank for XAMPP default)
```

### 5. Open in browser
`http://localhost/campus%20helper%20project/index.php`

---

## Default Admin Login
- **Email:** admin@campushelper.my
- **Password:** password

---

## VS Code Tips
- Install **PHP Intelephense** extension for PHP support
- Install **Live Server** for HTML preview
- Install **MySQL** extension for DB management
- Use `Ctrl + `` ` to open the terminal and run Git commands
