-- =============================================
--  campus_helper_db — database.sql
--  Run this in phpMyAdmin > Import
-- =============================================

CREATE DATABASE IF NOT EXISTS campus_helper_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_helper_db;

-- ─── USERS ───────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(120)  NOT NULL,
  email      VARCHAR(180)  NOT NULL UNIQUE,
  password   VARCHAR(255)  NOT NULL,
  role       ENUM('student','admin') DEFAULT 'student',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default accounts (password for all: password)
INSERT INTO users (name, email, password, role) VALUES
('Admin User',   'admin@campushelper.my',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Ahmad Razak',  'ahmad@campushelper.my',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student'),
('Siti Nabilah', 'siti@campushelper.my',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student');

-- ─── EVENTS ──────────────────────────────────
CREATE TABLE IF NOT EXISTS events (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(200) NOT NULL,
  description TEXT,
  event_date  DATE,
  location    VARCHAR(200),
  category    ENUM('Academic','Competition','Career','Social','Wellness','General') DEFAULT 'General',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO events (title, description, event_date, location, category) VALUES
('Orientation Day 2025',        'Welcome ceremony for new students. Includes campus tour and meet-the-dean session.',        '2025-07-15', 'Main Hall, Block A',      'Academic'),
('Tech Hackathon',              '24-hour coding competition. Form teams of 3-4 and build something amazing!',               '2025-07-22', 'Computer Lab, Block B',   'Competition'),
('Career Fair 2025',            'Meet over 40 companies hiring fresh graduates. Bring your CV!',                            '2025-08-05', 'Sports Hall, Block F',    'Career'),
('Cultural Night',              'Annual showcase of student performances, food stalls, and cultural exhibitions.',          '2025-08-12', 'Outdoor Amphitheatre',    'Social'),
('Mental Health Awareness Week','Workshops, talks, and activities focused on student wellbeing.',                           '2025-08-18', 'Student Centre',          'Wellness'),
('Research Symposium',          'Final-year students present their research projects to panels and peers.',                 '2025-09-01', 'Lecture Hall 4, Block D', 'Academic');

-- ─── RESOURCES ───────────────────────────────
CREATE TABLE IF NOT EXISTS resources (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(200) NOT NULL,
  subject      VARCHAR(80),
  subject_code VARCHAR(30),
  file_type    ENUM('PDF','PPTX','Video','XLSX','ZIP','DOC','Other') DEFAULT 'PDF',
  uploaded_by  VARCHAR(120),
  description  TEXT,
  file_path    VARCHAR(500) DEFAULT '#',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO resources (title, subject, subject_code, file_type, uploaded_by, description) VALUES
('Data Structures Notes',        'Data Structures',       'CS101',   'PDF',   'Dr. Ali Hassan',    'Week 1-5 lecture notes covering arrays, linked lists, stacks, queues.'),
('Web Programming Slides',       'Web Programming',       'CS204',   'PPTX',  'Dr. Siti Nora',     'HTML, CSS, JavaScript and PHP slides for all 14 weeks.'),
('Database Systems Past Papers', 'Database Systems',      'CS305',   'PDF',   'Dr. Lee Wei Ming',  'Final exam papers from 2022, 2023, 2024 with answers.'),
('Calculus II Formula Sheet',    'Calculus II',           'MATH102', 'PDF',   'Prof. Rajan Kumar', 'Quick reference for all calculus formulas covered in the syllabus.'),
('AI Lecture Recordings',        'Artificial Intelligence','CS402',  'Video', 'Dr. Kamil Yusuf',   'Recorded lectures on machine learning, neural networks, NLP.'),
('Software Eng. Templates',      'Software Engineering',  'CS401',   'ZIP',   'Dr. Farah Aziz',    'Project report templates, UML diagrams, SRS document samples.'),
('Networks Lab Manual',          'Computer Networks',     'CS303',   'PDF',   'Prof. Tan Boon',    'Step-by-step lab guides for Cisco Packet Tracer exercises.'),
('Project Mgmt Toolkit',         'Project Management',    'CS410',   'XLSX',  'Dr. Zara Ahmad',    'Gantt chart templates, risk matrix, project charter samples.');

-- ─── ANNOUNCEMENTS ───────────────────────────
CREATE TABLE IF NOT EXISTS announcements (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(200) NOT NULL,
  content     TEXT,
  posted_by   VARCHAR(120),
  type        ENUM('info','warning','urgent') DEFAULT 'info',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO announcements (title, content, posted_by, type) VALUES
('Final Exam Timetable Released',  'The official final examination timetable for Semester 2 2025 is now available. Please check your faculty notice board and the student portal.',  'Academic Office', 'urgent'),
('Library Extended Hours',          'The main library will be open 24 hours during the final exam period (Aug 20 – Sep 5). Access your student ID for entry after 10pm.',             'Library Services', 'info'),
('Scholarship Application Open',    'Applications for the National Excellence Scholarship 2025 are now open. Deadline: July 31. Visit the Financial Aid office for details.',        'Financial Aid',    'info'),
('Campus Wi-Fi Maintenance',        'Campus-wide Wi-Fi will be down for maintenance on July 13, 12am to 4am. Plan accordingly.',                                                     'IT Department',    'warning'),
('Student Council Elections',       'Nominations for the 2025/2026 Student Council are open. Submit your form at the Student Affairs office by July 20.',                           'Student Affairs',  'info');

-- ─── SCHEDULE ────────────────────────────────
CREATE TABLE IF NOT EXISTS schedule (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  day          ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  start_time   VARCHAR(20),
  end_time     VARCHAR(20),
  subject      VARCHAR(200),
  subject_code VARCHAR(30),
  lecturer     VARCHAR(120),
  room         VARCHAR(120),
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO schedule (day, start_time, end_time, subject, subject_code, lecturer, room) VALUES
('Monday',    '8:00 AM',  '10:00 AM', 'Data Structures',         'CS101',   'Dr. Ali Hassan',    'Block A, Room 203'),
('Monday',    '11:00 AM', '1:00 PM',  'Web Programming',         'CS204',   'Dr. Siti Nora',     'Lab 1, Block B'),
('Tuesday',   '8:00 AM',  '10:00 AM', 'Calculus II',             'MATH102', 'Prof. Rajan Kumar', 'Block C, Room 101'),
('Tuesday',   '2:00 PM',  '4:00 PM',  'Database Systems',        'CS305',   'Dr. Lee Wei Ming',  'Lab 2, Block B'),
('Wednesday', '10:00 AM', '12:00 PM', 'Software Engineering',    'CS401',   'Dr. Farah Aziz',    'Block A, Room 305'),
('Thursday',  '8:00 AM',  '10:00 AM', 'Computer Networks',       'CS303',   'Prof. Tan Boon',    'Block D, Room 202'),
('Thursday',  '11:00 AM', '1:00 PM',  'Artificial Intelligence', 'CS402',   'Dr. Kamil Yusuf',   'Block A, Room 401'),
('Friday',    '9:00 AM',  '11:00 AM', 'Project Management',      'CS410',   'Dr. Zara Ahmad',    'Block E, Room 110');

-- ─── CONTACT MESSAGES ────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(120) NOT NULL,
  email      VARCHAR(180) NOT NULL,
  subject    VARCHAR(200),
  message    TEXT,
  is_read    TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
