<?php
session_start();
require_once '../includes/db.php';

$result        = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
$announcements = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) $announcements[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Announcements — CampusHelper</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<nav class="navbar">
  <div class="nav-container">
    <a href="../index.php" class="nav-logo"><i class="fas fa-graduation-cap" style="color:var(--accent)"></i> Campus<span>Helper</span></a>
    <ul class="nav-links">
      <li><a href="../index.php">Home</a></li>
      <li><a href="schedule.php">Schedule</a></li>
      <li><a href="announcements.php" class="active">Announcements</a></li>
      <?php if (isset($_SESSION['user'])): ?>
        <li><a href="logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="login.php" class="btn-nav">Login</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<div class="inner-page">
  <div class="container">
    <div class="page-header">
      <h1><i class="fas fa-bullhorn" style="color:var(--accent);margin-right:10px;"></i>Announcements</h1>
      <p>Important notices from your faculty and campus offices.</p>
    </div>

    <div style="display:flex; flex-direction:column; gap:16px;">
      <?php foreach ($announcements as $a):
        $bStyle = match($a['type']) {
          'urgent'  => 'border-left:4px solid #f87171; background:rgba(239,68,68,0.06);',
          'warning' => 'border-left:4px solid #fbbf24; background:rgba(251,191,36,0.06);',
          default   => 'border-left:4px solid var(--primary);',
        };
        $icon = match($a['type']) {
          'urgent'  => '<i class="fas fa-exclamation-circle" style="color:#f87171;"></i>',
          'warning' => '<i class="fas fa-triangle-exclamation" style="color:#fbbf24;"></i>',
          default   => '<i class="fas fa-info-circle" style="color:var(--primary);"></i>',
        };
      ?>
      <div class="card event-card" style="<?= $bStyle ?>">
        <div style="display:flex; justify-content:space-between; align-items:start; gap:12px; flex-wrap:wrap;">
          <h3 style="font-family:'Syne',sans-serif; font-size:1rem; font-weight:700; display:flex; align-items:center; gap:8px;">
            <?= $icon ?> <?= htmlspecialchars($a['title']) ?>
          </h3>
          <span style="font-size:0.8rem; color:var(--text-muted); white-space:nowrap;">
            <?= date('d M Y', strtotime($a['created_at'])) ?>
          </span>
        </div>
        <p style="color:var(--text-muted); font-size:0.9rem; margin:10px 0 8px;"><?= htmlspecialchars($a['content']) ?></p>
        <span style="font-size:0.8rem; color:var(--text-muted);"><i class="fas fa-building" style="margin-right:4px;"></i><?= htmlspecialchars($a['posted_by']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script src="../js/main.js"></script>
</body>
</html>
