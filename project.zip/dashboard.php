<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
require_once '../includes/db.php';

$name = $_SESSION['name'];
$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard — CampusHelper</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<nav class="navbar">
  <div class="nav-container">
    <a href="../index.php" class="nav-logo"><i class="fas fa-graduation-cap" style="color:var(--accent)"></i> Campus<span>Helper</span></a>
    <ul class="nav-links">
      <li><a href="schedule.php">Schedule</a></li>
      <li><a href="resources.php">Resources</a></li>
      <li><a href="events.php">Events</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
</nav>

<div class="inner-page">
  <div class="container">
    <div class="page-header">
      <h1>Welcome, <?= htmlspecialchars($name) ?> 👋</h1>
      <p>Here's your campus overview for today.</p>
    </div>

    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px,1fr)); gap:20px; margin-bottom:40px;">
      <a href="schedule.php" class="card" style="display:block; text-decoration:none; transition:0.3s;">
        <div style="font-size:2rem; margin-bottom:12px;">📅</div>
        <h3 style="font-family:'Syne',sans-serif; margin-bottom:6px;">My Schedule</h3>
        <p style="color:var(--text-muted); font-size:0.9rem;">View today's classes and weekly timetable</p>
      </a>
      <a href="resources.php" class="card" style="display:block; text-decoration:none; transition:0.3s;">
        <div style="font-size:2rem; margin-bottom:12px;">📚</div>
        <h3 style="font-family:'Syne',sans-serif; margin-bottom:6px;">Resources</h3>
        <p style="color:var(--text-muted); font-size:0.9rem;">Study materials, notes, past papers</p>
      </a>
      <a href="events.php" class="card" style="display:block; text-decoration:none; transition:0.3s;">
        <div style="font-size:2rem; margin-bottom:12px;">🎉</div>
        <h3 style="font-family:'Syne',sans-serif; margin-bottom:6px;">Events</h3>
        <p style="color:var(--text-muted); font-size:0.9rem;">Upcoming campus events & activities</p>
      </a>
      <a href="announcements.php" class="card" style="display:block; text-decoration:none; transition:0.3s;">
        <div style="font-size:2rem; margin-bottom:12px;">📢</div>
        <h3 style="font-family:'Syne',sans-serif; margin-bottom:6px;">Announcements</h3>
        <p style="color:var(--text-muted); font-size:0.9rem;">Latest notices from faculty</p>
      </a>
    </div>

    <?php if ($role === 'admin'): ?>
    <div class="card">
      <h3 style="font-family:'Syne',sans-serif; margin-bottom:16px;">⚙️ Admin Panel</h3>
      <p style="color:var(--text-muted); margin-bottom:16px;">You have admin access. Manage content below.</p>
      <div style="display:flex; gap:12px; flex-wrap:wrap;">
        <a href="admin_events.php" class="btn-primary" style="font-size:0.9rem; padding:10px 20px;">Manage Events</a>
        <a href="admin_resources.php" class="btn-secondary" style="font-size:0.9rem; padding:10px 20px;">Manage Resources</a>
        <a href="admin_announcements.php" class="btn-secondary" style="font-size:0.9rem; padding:10px 20px;">Manage Announcements</a>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<script src="../js/main.js"></script>
</body>
</html>
