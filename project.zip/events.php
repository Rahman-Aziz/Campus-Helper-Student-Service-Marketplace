<?php
session_start();
require_once '../includes/db.php';

// Pull events from DB, fallback to sample data
$result = $conn->query("SELECT * FROM events ORDER BY event_date ASC");
$events = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) $events[] = $row;
} else {
    $events = [
        ['title'=>'Orientation Day 2025',       'description'=>'Welcome ceremony for new students. Includes campus tour and meet-the-dean session.', 'event_date'=>'2025-07-15', 'location'=>'Main Hall, Block A', 'category'=>'Academic'],
        ['title'=>'Tech Hackathon',             'description'=>'24-hour coding competition. Form teams of 3-4 and build something amazing!',            'event_date'=>'2025-07-22', 'location'=>'Computer Lab, Block B', 'category'=>'Competition'],
        ['title'=>'Career Fair 2025',           'description'=>'Meet over 40 companies hiring fresh graduates. Bring your CV!',                         'event_date'=>'2025-08-05', 'location'=>'Sports Hall, Block F', 'category'=>'Career'],
        ['title'=>'Cultural Night',             'description'=>'Annual showcase of student performances, food stalls, and cultural exhibitions.',        'event_date'=>'2025-08-12', 'location'=>'Outdoor Amphitheatre', 'category'=>'Social'],
        ['title'=>'Mental Health Awareness Week','description'=>'Workshops, talks, and activities focused on student wellbeing.',                        'event_date'=>'2025-08-18', 'location'=>'Student Centre',       'category'=>'Wellness'],
        ['title'=>'Research Symposium',         'description'=>'Final-year students present their research projects to panels and peers.',               'event_date'=>'2025-09-01', 'location'=>'Lecture Hall 4, Block D','category'=>'Academic'],
    ];
}
$categories = ['All','Academic','Competition','Career','Social','Wellness'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Events — CampusHelper</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>

<nav class="navbar">
  <div class="nav-container">
    <a href="../index.php" class="nav-logo"><i class="fas fa-graduation-cap" style="color:var(--accent)"></i> Campus<span>Helper</span></a>
    <ul class="nav-links">
      <li><a href="../index.php">Home</a></li>
      <li><a href="schedule.php">Schedule</a></li>
      <li><a href="resources.php">Resources</a></li>
      <li><a href="events.php" class="active">Events</a></li>
      <?php if (isset($_SESSION['user'])): ?>
        <li><a href="logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="login.php" class="btn-nav">Login</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<div class="inner-page">
  <div class="container">
    <div class="page-header">
      <h1><i class="fas fa-star" style="color:var(--accent);margin-right:10px;"></i>Campus Events</h1>
      <p>Stay updated with everything happening on campus.</p>
    </div>

    <!-- Filter -->
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:32px;" id="cat-tabs">
      <?php foreach ($categories as $c): ?>
        <button class="day-tab <?= $c==='All'?'active':'' ?>" data-cat="<?= $c ?>"><?= $c ?></button>
      <?php endforeach; ?>
    </div>

    <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(320px,1fr)); gap:20px;" id="events-grid">
      <?php foreach ($events as $ev):
        $date = isset($ev['event_date']) ? date('D, d M Y', strtotime($ev['event_date'])) : 'TBA';
        $cat  = $ev['category'] ?? 'General';
        $catClass = match($cat) {
          'Academic'    => 'badge-blue',
          'Competition' => 'badge-orange',
          'Career'      => 'badge-green',
          default       => 'badge-blue'
        };
      ?>
      <div class="card event-card" data-cat="<?= htmlspecialchars($cat) ?>" style="display:flex; flex-direction:column; gap:12px; transition:0.3s;">
        <div style="display:flex; justify-content:space-between; align-items:start;">
          <span class="badge <?= $catClass ?>"><?= htmlspecialchars($cat) ?></span>
          <span style="font-size:0.82rem; color:var(--text-muted);"><i class="fas fa-calendar" style="margin-right:4px;"></i><?= $date ?></span>
        </div>
        <h3 style="font-family:'Syne',sans-serif; font-size:1.05rem; font-weight:700;"><?= htmlspecialchars($ev['title']) ?></h3>
        <p style="color:var(--text-muted); font-size:0.9rem; flex:1;"><?= htmlspecialchars($ev['description']) ?></p>
        <div style="color:var(--text-muted); font-size:0.85rem;">
          <i class="fas fa-map-marker-alt" style="color:var(--primary); margin-right:6px;"></i>
          <?= htmlspecialchars($ev['location'] ?? 'TBA') ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<style>
.day-tab { padding:9px 18px; border-radius:8px; background:var(--surface); border:1px solid var(--border); color:var(--text-muted); font-family:'DM Sans',sans-serif; font-size:0.88rem; font-weight:600; cursor:pointer; transition:0.2s; }
.day-tab.active { background:var(--primary); color:#fff; border-color:var(--primary); }
.day-tab:hover:not(.active) { background:var(--surface2); color:var(--text); }
.event-card:hover { border-color:rgba(26,86,240,0.4); transform:translateY(-4px); box-shadow:0 12px 32px rgba(0,0,0,0.3); }
</style>

<script>
document.querySelectorAll('#cat-tabs .day-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#cat-tabs .day-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const cat = btn.dataset.cat;
    document.querySelectorAll('.event-card').forEach(card => {
      card.style.display = (cat === 'All' || card.dataset.cat === cat) ? '' : 'none';
    });
  });
});
</script>
<script src="../js/main.js"></script>
</body>
</html>
